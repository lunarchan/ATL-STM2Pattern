/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Attribute#getAccessright <em>Accessright</em>}</li>
 *   <li>{@link Pattern.Attribute#getAttributetype <em>Attributetype</em>}</li>
 *   <li>{@link Pattern.Attribute#getStaticflag <em>Staticflag</em>}</li>
 *   <li>{@link Pattern.Attribute#getCiteName <em>Cite Name</em>}</li>
 *   <li>{@link Pattern.Attribute#getMulti <em>Multi</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends NameElement {
	/**
	 * Returns the value of the '<em><b>Accessright</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.AccessRightsType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Accessright</em>' attribute.
	 * @see Pattern.AccessRightsType
	 * @see #setAccessright(AccessRightsType)
	 * @see Pattern.PatternPackage#getAttribute_Accessright()
	 * @model
	 * @generated
	 */
	AccessRightsType getAccessright();

	/**
	 * Sets the value of the '{@link Pattern.Attribute#getAccessright <em>Accessright</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Accessright</em>' attribute.
	 * @see Pattern.AccessRightsType
	 * @see #getAccessright()
	 * @generated
	 */
	void setAccessright(AccessRightsType value);

	/**
	 * Returns the value of the '<em><b>Attributetype</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.DataType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributetype</em>' attribute.
	 * @see Pattern.DataType
	 * @see #setAttributetype(DataType)
	 * @see Pattern.PatternPackage#getAttribute_Attributetype()
	 * @model
	 * @generated
	 */
	DataType getAttributetype();

	/**
	 * Sets the value of the '{@link Pattern.Attribute#getAttributetype <em>Attributetype</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attributetype</em>' attribute.
	 * @see Pattern.DataType
	 * @see #getAttributetype()
	 * @generated
	 */
	void setAttributetype(DataType value);

	/**
	 * Returns the value of the '<em><b>Staticflag</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.StaticType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Staticflag</em>' attribute.
	 * @see Pattern.StaticType
	 * @see #setStaticflag(StaticType)
	 * @see Pattern.PatternPackage#getAttribute_Staticflag()
	 * @model
	 * @generated
	 */
	StaticType getStaticflag();

	/**
	 * Sets the value of the '{@link Pattern.Attribute#getStaticflag <em>Staticflag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Staticflag</em>' attribute.
	 * @see Pattern.StaticType
	 * @see #getStaticflag()
	 * @generated
	 */
	void setStaticflag(StaticType value);

	/**
	 * Returns the value of the '<em><b>Cite Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cite Name</em>' attribute.
	 * @see #setCiteName(String)
	 * @see Pattern.PatternPackage#getAttribute_CiteName()
	 * @model
	 * @generated
	 */
	String getCiteName();

	/**
	 * Sets the value of the '{@link Pattern.Attribute#getCiteName <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cite Name</em>' attribute.
	 * @see #getCiteName()
	 * @generated
	 */
	void setCiteName(String value);

	/**
	 * Returns the value of the '<em><b>Multi</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.MultiType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #setMulti(MultiType)
	 * @see Pattern.PatternPackage#getAttribute_Multi()
	 * @model
	 * @generated
	 */
	MultiType getMulti();

	/**
	 * Sets the value of the '{@link Pattern.Attribute#getMulti <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #getMulti()
	 * @generated
	 */
	void setMulti(MultiType value);

} // Attribute
