/**
 */
package Pattern;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Class#getNewAttribute <em>New Attribute</em>}</li>
 *   <li>{@link Pattern.Class#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link Pattern.Class#getOperations <em>Operations</em>}</li>
 *   <li>{@link Pattern.Class#getRoleTe <em>Role Te</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getClass_()
 * @model
 * @generated
 */
public interface Class extends NameElement {
	/**
	 * Returns the value of the '<em><b>New Attribute</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.AbstractType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>New Attribute</em>' attribute.
	 * @see Pattern.AbstractType
	 * @see #setNewAttribute(AbstractType)
	 * @see Pattern.PatternPackage#getClass_NewAttribute()
	 * @model
	 * @generated
	 */
	AbstractType getNewAttribute();

	/**
	 * Sets the value of the '{@link Pattern.Class#getNewAttribute <em>New Attribute</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>New Attribute</em>' attribute.
	 * @see Pattern.AbstractType
	 * @see #getNewAttribute()
	 * @generated
	 */
	void setNewAttribute(AbstractType value);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Attribute}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see Pattern.PatternPackage#getClass_Attributes()
	 * @model containment="true"
	 * @generated
	 */
	EList<Attribute> getAttributes();

	/**
	 * Returns the value of the '<em><b>Operations</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Operation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operations</em>' containment reference list.
	 * @see Pattern.PatternPackage#getClass_Operations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operation> getOperations();

	/**
	 * Returns the value of the '<em><b>Role Te</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.RoleOf}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role Te</em>' containment reference list.
	 * @see Pattern.PatternPackage#getClass_RoleTe()
	 * @model containment="true"
	 * @generated
	 */
	EList<RoleOf> getRoleTe();

} // Class
