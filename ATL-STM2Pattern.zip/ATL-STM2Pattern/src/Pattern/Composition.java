/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Composition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Composition#getSource <em>Source</em>}</li>
 *   <li>{@link Pattern.Composition#getTarget <em>Target</em>}</li>
 *   <li>{@link Pattern.Composition#getRName <em>RName</em>}</li>
 *   <li>{@link Pattern.Composition#getMulti <em>Multi</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getComposition()
 * @model
 * @generated
 */
public interface Composition extends NameElement {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Role)
	 * @see Pattern.PatternPackage#getComposition_Source()
	 * @model required="true"
	 * @generated
	 */
	Role getSource();

	/**
	 * Sets the value of the '{@link Pattern.Composition#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Role value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(RoleElement)
	 * @see Pattern.PatternPackage#getComposition_Target()
	 * @model required="true"
	 * @generated
	 */
	RoleElement getTarget();

	/**
	 * Sets the value of the '{@link Pattern.Composition#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(RoleElement value);

	/**
	 * Returns the value of the '<em><b>RName</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>RName</em>' attribute.
	 * @see #setRName(String)
	 * @see Pattern.PatternPackage#getComposition_RName()
	 * @model
	 * @generated
	 */
	String getRName();

	/**
	 * Sets the value of the '{@link Pattern.Composition#getRName <em>RName</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>RName</em>' attribute.
	 * @see #getRName()
	 * @generated
	 */
	void setRName(String value);

	/**
	 * Returns the value of the '<em><b>Multi</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.MultiType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #setMulti(MultiType)
	 * @see Pattern.PatternPackage#getComposition_Multi()
	 * @model
	 * @generated
	 */
	MultiType getMulti();

	/**
	 * Sets the value of the '{@link Pattern.Composition#getMulti <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #getMulti()
	 * @generated
	 */
	void setMulti(MultiType value);

} // Composition
