/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dependence</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Dependence#getSource <em>Source</em>}</li>
 *   <li>{@link Pattern.Dependence#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getDependence()
 * @model
 * @generated
 */
public interface Dependence extends NameElement {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Role)
	 * @see Pattern.PatternPackage#getDependence_Source()
	 * @model required="true"
	 * @generated
	 */
	Role getSource();

	/**
	 * Sets the value of the '{@link Pattern.Dependence#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Role value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(RoleElement)
	 * @see Pattern.PatternPackage#getDependence_Target()
	 * @model required="true"
	 * @generated
	 */
	RoleElement getTarget();

	/**
	 * Sets the value of the '{@link Pattern.Dependence#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(RoleElement value);

} // Dependence
