/**
 */
package Pattern;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Design Pattern</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.DesignPattern#getRoles <em>Roles</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getClasses <em>Classes</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getRoleofs <em>Roleofs</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getGeneralizations <em>Generalizations</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getDependences <em>Dependences</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getAggregations <em>Aggregations</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getCompositions <em>Compositions</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getDirectedassociations <em>Directedassociations</em>}</li>
 *   <li>{@link Pattern.DesignPattern#getRealizations <em>Realizations</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getDesignPattern()
 * @model
 * @generated
 */
public interface DesignPattern extends NameElement {
	/**
	 * Returns the value of the '<em><b>Roles</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.RoleElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Roles</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Roles()
	 * @model containment="true"
	 * @generated
	 */
	EList<RoleElement> getRoles();

	/**
	 * Returns the value of the '<em><b>Classes</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Class}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Classes</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Classes()
	 * @model containment="true"
	 * @generated
	 */
	EList<Pattern.Class> getClasses();

	/**
	 * Returns the value of the '<em><b>Roleofs</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.RoleOf}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Roleofs</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Roleofs()
	 * @model containment="true"
	 * @generated
	 */
	EList<RoleOf> getRoleofs();

	/**
	 * Returns the value of the '<em><b>Generalizations</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Generalization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Generalizations</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Generalizations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Generalization> getGeneralizations();

	/**
	 * Returns the value of the '<em><b>Dependences</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Dependence}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependences</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Dependences()
	 * @model containment="true"
	 * @generated
	 */
	EList<Dependence> getDependences();

	/**
	 * Returns the value of the '<em><b>Aggregations</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Aggregation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregations</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Aggregations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Aggregation> getAggregations();

	/**
	 * Returns the value of the '<em><b>Compositions</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Composition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Compositions</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Compositions()
	 * @model containment="true"
	 * @generated
	 */
	EList<Composition> getCompositions();

	/**
	 * Returns the value of the '<em><b>Directedassociations</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.DirectedAssociation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Directedassociations</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Directedassociations()
	 * @model containment="true"
	 * @generated
	 */
	EList<DirectedAssociation> getDirectedassociations();

	/**
	 * Returns the value of the '<em><b>Realizations</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Realization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Realizations</em>' containment reference list.
	 * @see Pattern.PatternPackage#getDesignPattern_Realizations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Realization> getRealizations();

} // DesignPattern
