/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Directed Association</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.DirectedAssociation#getMulti <em>Multi</em>}</li>
 *   <li>{@link Pattern.DirectedAssociation#getSource <em>Source</em>}</li>
 *   <li>{@link Pattern.DirectedAssociation#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getDirectedAssociation()
 * @model
 * @generated
 */
public interface DirectedAssociation extends NameElement {
	/**
	 * Returns the value of the '<em><b>Multi</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.MultiType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #setMulti(MultiType)
	 * @see Pattern.PatternPackage#getDirectedAssociation_Multi()
	 * @model
	 * @generated
	 */
	MultiType getMulti();

	/**
	 * Sets the value of the '{@link Pattern.DirectedAssociation#getMulti <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #getMulti()
	 * @generated
	 */
	void setMulti(MultiType value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Role)
	 * @see Pattern.PatternPackage#getDirectedAssociation_Source()
	 * @model required="true"
	 * @generated
	 */
	Role getSource();

	/**
	 * Sets the value of the '{@link Pattern.DirectedAssociation#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Role value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(RoleElement)
	 * @see Pattern.PatternPackage#getDirectedAssociation_Target()
	 * @model required="true"
	 * @generated
	 */
	RoleElement getTarget();

	/**
	 * Sets the value of the '{@link Pattern.DirectedAssociation#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(RoleElement value);

} // DirectedAssociation
