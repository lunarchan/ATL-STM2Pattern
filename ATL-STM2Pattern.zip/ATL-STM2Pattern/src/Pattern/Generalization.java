/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generalization</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Generalization#getSource <em>Source</em>}</li>
 *   <li>{@link Pattern.Generalization#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getGeneralization()
 * @model
 * @generated
 */
public interface Generalization extends NameElement {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Role)
	 * @see Pattern.PatternPackage#getGeneralization_Source()
	 * @model required="true"
	 * @generated
	 */
	Role getSource();

	/**
	 * Sets the value of the '{@link Pattern.Generalization#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Role value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Role)
	 * @see Pattern.PatternPackage#getGeneralization_Target()
	 * @model required="true"
	 * @generated
	 */
	Role getTarget();

	/**
	 * Sets the value of the '{@link Pattern.Generalization#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Role value);

} // Generalization
