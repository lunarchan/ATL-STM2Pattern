/**
 */
package Pattern;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Operation#getReturnType <em>Return Type</em>}</li>
 *   <li>{@link Pattern.Operation#getAccessright <em>Accessright</em>}</li>
 *   <li>{@link Pattern.Operation#getStaticFlag <em>Static Flag</em>}</li>
 *   <li>{@link Pattern.Operation#getCiteName <em>Cite Name</em>}</li>
 *   <li>{@link Pattern.Operation#getMulti <em>Multi</em>}</li>
 *   <li>{@link Pattern.Operation#getParams <em>Params</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getOperation()
 * @model
 * @generated
 */
public interface Operation extends NameElement {
	/**
	 * Returns the value of the '<em><b>Return Type</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.DataType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Return Type</em>' attribute.
	 * @see Pattern.DataType
	 * @see #setReturnType(DataType)
	 * @see Pattern.PatternPackage#getOperation_ReturnType()
	 * @model
	 * @generated
	 */
	DataType getReturnType();

	/**
	 * Sets the value of the '{@link Pattern.Operation#getReturnType <em>Return Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Return Type</em>' attribute.
	 * @see Pattern.DataType
	 * @see #getReturnType()
	 * @generated
	 */
	void setReturnType(DataType value);

	/**
	 * Returns the value of the '<em><b>Accessright</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.AccessRightsType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Accessright</em>' attribute.
	 * @see Pattern.AccessRightsType
	 * @see #setAccessright(AccessRightsType)
	 * @see Pattern.PatternPackage#getOperation_Accessright()
	 * @model
	 * @generated
	 */
	AccessRightsType getAccessright();

	/**
	 * Sets the value of the '{@link Pattern.Operation#getAccessright <em>Accessright</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Accessright</em>' attribute.
	 * @see Pattern.AccessRightsType
	 * @see #getAccessright()
	 * @generated
	 */
	void setAccessright(AccessRightsType value);

	/**
	 * Returns the value of the '<em><b>Static Flag</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.StaticType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Static Flag</em>' attribute.
	 * @see Pattern.StaticType
	 * @see #setStaticFlag(StaticType)
	 * @see Pattern.PatternPackage#getOperation_StaticFlag()
	 * @model
	 * @generated
	 */
	StaticType getStaticFlag();

	/**
	 * Sets the value of the '{@link Pattern.Operation#getStaticFlag <em>Static Flag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Static Flag</em>' attribute.
	 * @see Pattern.StaticType
	 * @see #getStaticFlag()
	 * @generated
	 */
	void setStaticFlag(StaticType value);

	/**
	 * Returns the value of the '<em><b>Cite Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cite Name</em>' attribute.
	 * @see #setCiteName(String)
	 * @see Pattern.PatternPackage#getOperation_CiteName()
	 * @model
	 * @generated
	 */
	String getCiteName();

	/**
	 * Sets the value of the '{@link Pattern.Operation#getCiteName <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cite Name</em>' attribute.
	 * @see #getCiteName()
	 * @generated
	 */
	void setCiteName(String value);

	/**
	 * Returns the value of the '<em><b>Multi</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.MultiType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #setMulti(MultiType)
	 * @see Pattern.PatternPackage#getOperation_Multi()
	 * @model
	 * @generated
	 */
	MultiType getMulti();

	/**
	 * Sets the value of the '{@link Pattern.Operation#getMulti <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #getMulti()
	 * @generated
	 */
	void setMulti(MultiType value);

	/**
	 * Returns the value of the '<em><b>Params</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Parameter}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Params</em>' containment reference list.
	 * @see Pattern.PatternPackage#getOperation_Params()
	 * @model containment="true"
	 * @generated
	 */
	EList<Parameter> getParams();

} // Operation
