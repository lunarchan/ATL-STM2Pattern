/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Parameter#getParameterType <em>Parameter Type</em>}</li>
 *   <li>{@link Pattern.Parameter#getCiteName <em>Cite Name</em>}</li>
 *   <li>{@link Pattern.Parameter#getMulti <em>Multi</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getParameter()
 * @model
 * @generated
 */
public interface Parameter extends NameElement {
	/**
	 * Returns the value of the '<em><b>Parameter Type</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.DataType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameter Type</em>' attribute.
	 * @see Pattern.DataType
	 * @see #setParameterType(DataType)
	 * @see Pattern.PatternPackage#getParameter_ParameterType()
	 * @model required="true"
	 * @generated
	 */
	DataType getParameterType();

	/**
	 * Sets the value of the '{@link Pattern.Parameter#getParameterType <em>Parameter Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parameter Type</em>' attribute.
	 * @see Pattern.DataType
	 * @see #getParameterType()
	 * @generated
	 */
	void setParameterType(DataType value);

	/**
	 * Returns the value of the '<em><b>Cite Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cite Name</em>' attribute.
	 * @see #setCiteName(String)
	 * @see Pattern.PatternPackage#getParameter_CiteName()
	 * @model
	 * @generated
	 */
	String getCiteName();

	/**
	 * Sets the value of the '{@link Pattern.Parameter#getCiteName <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cite Name</em>' attribute.
	 * @see #getCiteName()
	 * @generated
	 */
	void setCiteName(String value);

	/**
	 * Returns the value of the '<em><b>Multi</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.MultiType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #setMulti(MultiType)
	 * @see Pattern.PatternPackage#getParameter_Multi()
	 * @model
	 * @generated
	 */
	MultiType getMulti();

	/**
	 * Sets the value of the '{@link Pattern.Parameter#getMulti <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multi</em>' attribute.
	 * @see Pattern.MultiType
	 * @see #getMulti()
	 * @generated
	 */
	void setMulti(MultiType value);

} // Parameter
