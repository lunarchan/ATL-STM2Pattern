/**
 */
package Pattern;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see Pattern.PatternFactory
 * @model kind="package"
 * @generated
 */
public interface PatternPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Pattern";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://pattern/1.0";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "pattern";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PatternPackage eINSTANCE = Pattern.impl.PatternPackageImpl.init();

	/**
	 * The meta object id for the '{@link Pattern.impl.NameElementImpl <em>Name Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.NameElementImpl
	 * @see Pattern.impl.PatternPackageImpl#getNameElement()
	 * @generated
	 */
	int NAME_ELEMENT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME_ELEMENT__NAME = 0;

	/**
	 * The number of structural features of the '<em>Name Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME_ELEMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Name Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.DesignPatternImpl <em>Design Pattern</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.DesignPatternImpl
	 * @see Pattern.impl.PatternPackageImpl#getDesignPattern()
	 * @generated
	 */
	int DESIGN_PATTERN = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Roles</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__ROLES = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Classes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__CLASSES = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Roleofs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__ROLEOFS = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Generalizations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__GENERALIZATIONS = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Dependences</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__DEPENDENCES = NAME_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Aggregations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__AGGREGATIONS = NAME_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Compositions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__COMPOSITIONS = NAME_ELEMENT_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Directedassociations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__DIRECTEDASSOCIATIONS = NAME_ELEMENT_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Realizations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN__REALIZATIONS = NAME_ELEMENT_FEATURE_COUNT + 8;

	/**
	 * The number of structural features of the '<em>Design Pattern</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 9;

	/**
	 * The number of operations of the '<em>Design Pattern</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESIGN_PATTERN_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.ClassImpl <em>Class</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.ClassImpl
	 * @see Pattern.impl.PatternPackageImpl#getClass_()
	 * @generated
	 */
	int CLASS = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>New Attribute</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__NEW_ATTRIBUTE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__ATTRIBUTES = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Operations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__OPERATIONS = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Role Te</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__ROLE_TE = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.RoleElementImpl <em>Role Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.RoleElementImpl
	 * @see Pattern.impl.PatternPackageImpl#getRoleElement()
	 * @generated
	 */
	int ROLE_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Role From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT__ROLE_FROM = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Realization To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT__REALIZATION_TO = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Dependence From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT__DEPENDENCE_FROM = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Aggregation From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT__AGGREGATION_FROM = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Composition From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT__COMPOSITION_FROM = NAME_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Directedassociation From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM = NAME_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Role Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Role Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_ELEMENT_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.RoleImpl <em>Role</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.RoleImpl
	 * @see Pattern.impl.PatternPackageImpl#getRole()
	 * @generated
	 */
	int ROLE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__NAME = ROLE_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Role From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__ROLE_FROM = ROLE_ELEMENT__ROLE_FROM;

	/**
	 * The feature id for the '<em><b>Realization To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__REALIZATION_TO = ROLE_ELEMENT__REALIZATION_TO;

	/**
	 * The feature id for the '<em><b>Dependence From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__DEPENDENCE_FROM = ROLE_ELEMENT__DEPENDENCE_FROM;

	/**
	 * The feature id for the '<em><b>Aggregation From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__AGGREGATION_FROM = ROLE_ELEMENT__AGGREGATION_FROM;

	/**
	 * The feature id for the '<em><b>Composition From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__COMPOSITION_FROM = ROLE_ELEMENT__COMPOSITION_FROM;

	/**
	 * The feature id for the '<em><b>Directedassociation From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__DIRECTEDASSOCIATION_FROM = ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM;

	/**
	 * The feature id for the '<em><b>Abstractflag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__ABSTRACTFLAG = ROLE_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Generalization To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__GENERALIZATION_TO = ROLE_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__ATTRIBUTES = ROLE_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Operations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__OPERATIONS = ROLE_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Dependence To</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__DEPENDENCE_TO = ROLE_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Aggregation To</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__AGGREGATION_TO = ROLE_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Composition To</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__COMPOSITION_TO = ROLE_ELEMENT_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Directedassociation To</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__DIRECTEDASSOCIATION_TO = ROLE_ELEMENT_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Generalization From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__GENERALIZATION_FROM = ROLE_ELEMENT_FEATURE_COUNT + 8;

	/**
	 * The number of structural features of the '<em>Role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FEATURE_COUNT = ROLE_ELEMENT_FEATURE_COUNT + 9;

	/**
	 * The number of operations of the '<em>Role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OPERATION_COUNT = ROLE_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.RoleInterfaceImpl <em>Role Interface</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.RoleInterfaceImpl
	 * @see Pattern.impl.PatternPackageImpl#getRoleInterface()
	 * @generated
	 */
	int ROLE_INTERFACE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__NAME = ROLE_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Role From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__ROLE_FROM = ROLE_ELEMENT__ROLE_FROM;

	/**
	 * The feature id for the '<em><b>Realization To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__REALIZATION_TO = ROLE_ELEMENT__REALIZATION_TO;

	/**
	 * The feature id for the '<em><b>Dependence From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__DEPENDENCE_FROM = ROLE_ELEMENT__DEPENDENCE_FROM;

	/**
	 * The feature id for the '<em><b>Aggregation From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__AGGREGATION_FROM = ROLE_ELEMENT__AGGREGATION_FROM;

	/**
	 * The feature id for the '<em><b>Composition From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__COMPOSITION_FROM = ROLE_ELEMENT__COMPOSITION_FROM;

	/**
	 * The feature id for the '<em><b>Directedassociation From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__DIRECTEDASSOCIATION_FROM = ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM;

	/**
	 * The feature id for the '<em><b>Operations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__OPERATIONS = ROLE_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Realization From</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE__REALIZATION_FROM = ROLE_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Role Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE_FEATURE_COUNT = ROLE_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Role Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_INTERFACE_OPERATION_COUNT = ROLE_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.AttributeImpl <em>Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.AttributeImpl
	 * @see Pattern.impl.PatternPackageImpl#getAttribute()
	 * @generated
	 */
	int ATTRIBUTE = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Accessright</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__ACCESSRIGHT = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Attributetype</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__ATTRIBUTETYPE = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Staticflag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__STATICFLAG = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Cite Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__CITE_NAME = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Multi</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__MULTI = NAME_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.ParameterImpl <em>Parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.ParameterImpl
	 * @see Pattern.impl.PatternPackageImpl#getParameter()
	 * @generated
	 */
	int PARAMETER = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Parameter Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__PARAMETER_TYPE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Cite Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__CITE_NAME = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Multi</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__MULTI = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.OperationImpl <em>Operation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.OperationImpl
	 * @see Pattern.impl.PatternPackageImpl#getOperation()
	 * @generated
	 */
	int OPERATION = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Return Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__RETURN_TYPE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Accessright</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__ACCESSRIGHT = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Static Flag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__STATIC_FLAG = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Cite Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__CITE_NAME = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Multi</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__MULTI = NAME_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Params</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION__PARAMS = NAME_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Operation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Operation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATION_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.RoleOfImpl <em>Role Of</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.RoleOfImpl
	 * @see Pattern.impl.PatternPackageImpl#getRoleOf()
	 * @generated
	 */
	int ROLE_OF = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OF__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OF__SOURCE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OF__TARGET = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Role Of</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OF_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Role Of</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OF_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.DependenceImpl <em>Dependence</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.DependenceImpl
	 * @see Pattern.impl.PatternPackageImpl#getDependence()
	 * @generated
	 */
	int DEPENDENCE = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCE__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCE__SOURCE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCE__TARGET = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Dependence</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCE_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Dependence</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCE_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.AggregationImpl <em>Aggregation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.AggregationImpl
	 * @see Pattern.impl.PatternPackageImpl#getAggregation()
	 * @generated
	 */
	int AGGREGATION = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION__SOURCE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION__TARGET = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>RName</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION__RNAME = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Multi</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION__MULTI = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Aggregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Aggregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.CompositionImpl <em>Composition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.CompositionImpl
	 * @see Pattern.impl.PatternPackageImpl#getComposition()
	 * @generated
	 */
	int COMPOSITION = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__SOURCE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__TARGET = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>RName</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__RNAME = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Multi</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION__MULTI = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Composition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Composition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.DirectedAssociationImpl <em>Directed Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.DirectedAssociationImpl
	 * @see Pattern.impl.PatternPackageImpl#getDirectedAssociation()
	 * @generated
	 */
	int DIRECTED_ASSOCIATION = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIRECTED_ASSOCIATION__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Multi</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIRECTED_ASSOCIATION__MULTI = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIRECTED_ASSOCIATION__SOURCE = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIRECTED_ASSOCIATION__TARGET = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Directed Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIRECTED_ASSOCIATION_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Directed Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIRECTED_ASSOCIATION_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.RealizationImpl <em>Realization</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.RealizationImpl
	 * @see Pattern.impl.PatternPackageImpl#getRealization()
	 * @generated
	 */
	int REALIZATION = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REALIZATION__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REALIZATION__SOURCE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REALIZATION__TARGET = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Realization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REALIZATION_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Realization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REALIZATION_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.impl.GeneralizationImpl <em>Generalization</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.impl.GeneralizationImpl
	 * @see Pattern.impl.PatternPackageImpl#getGeneralization()
	 * @generated
	 */
	int GENERALIZATION = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__NAME = NAME_ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__SOURCE = NAME_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__TARGET = NAME_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Generalization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION_FEATURE_COUNT = NAME_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Generalization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION_OPERATION_COUNT = NAME_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link Pattern.AccessRightsType <em>Access Rights Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.AccessRightsType
	 * @see Pattern.impl.PatternPackageImpl#getAccessRightsType()
	 * @generated
	 */
	int ACCESS_RIGHTS_TYPE = 16;

	/**
	 * The meta object id for the '{@link Pattern.DataType <em>Data Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.DataType
	 * @see Pattern.impl.PatternPackageImpl#getDataType()
	 * @generated
	 */
	int DATA_TYPE = 17;

	/**
	 * The meta object id for the '{@link Pattern.StaticType <em>Static Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.StaticType
	 * @see Pattern.impl.PatternPackageImpl#getStaticType()
	 * @generated
	 */
	int STATIC_TYPE = 18;

	/**
	 * The meta object id for the '{@link Pattern.AbstractType <em>Abstract Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.AbstractType
	 * @see Pattern.impl.PatternPackageImpl#getAbstractType()
	 * @generated
	 */
	int ABSTRACT_TYPE = 19;

	/**
	 * The meta object id for the '{@link Pattern.MultiType <em>Multi Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Pattern.MultiType
	 * @see Pattern.impl.PatternPackageImpl#getMultiType()
	 * @generated
	 */
	int MULTI_TYPE = 20;


	/**
	 * Returns the meta object for class '{@link Pattern.NameElement <em>Name Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Name Element</em>'.
	 * @see Pattern.NameElement
	 * @generated
	 */
	EClass getNameElement();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.NameElement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see Pattern.NameElement#getName()
	 * @see #getNameElement()
	 * @generated
	 */
	EAttribute getNameElement_Name();

	/**
	 * Returns the meta object for class '{@link Pattern.DesignPattern <em>Design Pattern</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Design Pattern</em>'.
	 * @see Pattern.DesignPattern
	 * @generated
	 */
	EClass getDesignPattern();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getRoles <em>Roles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Roles</em>'.
	 * @see Pattern.DesignPattern#getRoles()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Roles();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getClasses <em>Classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Classes</em>'.
	 * @see Pattern.DesignPattern#getClasses()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Classes();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getRoleofs <em>Roleofs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Roleofs</em>'.
	 * @see Pattern.DesignPattern#getRoleofs()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Roleofs();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getGeneralizations <em>Generalizations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Generalizations</em>'.
	 * @see Pattern.DesignPattern#getGeneralizations()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Generalizations();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getDependences <em>Dependences</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependences</em>'.
	 * @see Pattern.DesignPattern#getDependences()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Dependences();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getAggregations <em>Aggregations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregations</em>'.
	 * @see Pattern.DesignPattern#getAggregations()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Aggregations();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getCompositions <em>Compositions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Compositions</em>'.
	 * @see Pattern.DesignPattern#getCompositions()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Compositions();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getDirectedassociations <em>Directedassociations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Directedassociations</em>'.
	 * @see Pattern.DesignPattern#getDirectedassociations()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Directedassociations();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.DesignPattern#getRealizations <em>Realizations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Realizations</em>'.
	 * @see Pattern.DesignPattern#getRealizations()
	 * @see #getDesignPattern()
	 * @generated
	 */
	EReference getDesignPattern_Realizations();

	/**
	 * Returns the meta object for class '{@link Pattern.Class <em>Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Class</em>'.
	 * @see Pattern.Class
	 * @generated
	 */
	EClass getClass_();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Class#getNewAttribute <em>New Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>New Attribute</em>'.
	 * @see Pattern.Class#getNewAttribute()
	 * @see #getClass_()
	 * @generated
	 */
	EAttribute getClass_NewAttribute();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Class#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see Pattern.Class#getAttributes()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_Attributes();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Class#getOperations <em>Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operations</em>'.
	 * @see Pattern.Class#getOperations()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_Operations();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Class#getRoleTe <em>Role Te</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Role Te</em>'.
	 * @see Pattern.Class#getRoleTe()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_RoleTe();

	/**
	 * Returns the meta object for class '{@link Pattern.RoleElement <em>Role Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Element</em>'.
	 * @see Pattern.RoleElement
	 * @generated
	 */
	EClass getRoleElement();

	/**
	 * Returns the meta object for the reference '{@link Pattern.RoleElement#getRoleFrom <em>Role From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Role From</em>'.
	 * @see Pattern.RoleElement#getRoleFrom()
	 * @see #getRoleElement()
	 * @generated
	 */
	EReference getRoleElement_RoleFrom();

	/**
	 * Returns the meta object for the reference '{@link Pattern.RoleElement#getRealizationTo <em>Realization To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Realization To</em>'.
	 * @see Pattern.RoleElement#getRealizationTo()
	 * @see #getRoleElement()
	 * @generated
	 */
	EReference getRoleElement_RealizationTo();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.RoleElement#getDependenceFrom <em>Dependence From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependence From</em>'.
	 * @see Pattern.RoleElement#getDependenceFrom()
	 * @see #getRoleElement()
	 * @generated
	 */
	EReference getRoleElement_DependenceFrom();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.RoleElement#getAggregationFrom <em>Aggregation From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation From</em>'.
	 * @see Pattern.RoleElement#getAggregationFrom()
	 * @see #getRoleElement()
	 * @generated
	 */
	EReference getRoleElement_AggregationFrom();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.RoleElement#getCompositionFrom <em>Composition From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Composition From</em>'.
	 * @see Pattern.RoleElement#getCompositionFrom()
	 * @see #getRoleElement()
	 * @generated
	 */
	EReference getRoleElement_CompositionFrom();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.RoleElement#getDirectedassociationFrom <em>Directedassociation From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Directedassociation From</em>'.
	 * @see Pattern.RoleElement#getDirectedassociationFrom()
	 * @see #getRoleElement()
	 * @generated
	 */
	EReference getRoleElement_DirectedassociationFrom();

	/**
	 * Returns the meta object for class '{@link Pattern.Role <em>Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role</em>'.
	 * @see Pattern.Role
	 * @generated
	 */
	EClass getRole();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Role#getAbstractflag <em>Abstractflag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Abstractflag</em>'.
	 * @see Pattern.Role#getAbstractflag()
	 * @see #getRole()
	 * @generated
	 */
	EAttribute getRole_Abstractflag();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Role#getGeneralizationTo <em>Generalization To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Generalization To</em>'.
	 * @see Pattern.Role#getGeneralizationTo()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_GeneralizationTo();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Role#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see Pattern.Role#getAttributes()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_Attributes();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Role#getOperations <em>Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operations</em>'.
	 * @see Pattern.Role#getOperations()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_Operations();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Role#getDependenceTo <em>Dependence To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependence To</em>'.
	 * @see Pattern.Role#getDependenceTo()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_DependenceTo();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Role#getAggregationTo <em>Aggregation To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation To</em>'.
	 * @see Pattern.Role#getAggregationTo()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_AggregationTo();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Role#getCompositionTo <em>Composition To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Composition To</em>'.
	 * @see Pattern.Role#getCompositionTo()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_CompositionTo();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Role#getDirectedassociationTo <em>Directedassociation To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Directedassociation To</em>'.
	 * @see Pattern.Role#getDirectedassociationTo()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_DirectedassociationTo();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Role#getGeneralizationFrom <em>Generalization From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Generalization From</em>'.
	 * @see Pattern.Role#getGeneralizationFrom()
	 * @see #getRole()
	 * @generated
	 */
	EReference getRole_GeneralizationFrom();

	/**
	 * Returns the meta object for class '{@link Pattern.RoleInterface <em>Role Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Interface</em>'.
	 * @see Pattern.RoleInterface
	 * @generated
	 */
	EClass getRoleInterface();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.RoleInterface#getOperations <em>Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Operations</em>'.
	 * @see Pattern.RoleInterface#getOperations()
	 * @see #getRoleInterface()
	 * @generated
	 */
	EReference getRoleInterface_Operations();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.RoleInterface#getRealizationFrom <em>Realization From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Realization From</em>'.
	 * @see Pattern.RoleInterface#getRealizationFrom()
	 * @see #getRoleInterface()
	 * @generated
	 */
	EReference getRoleInterface_RealizationFrom();

	/**
	 * Returns the meta object for class '{@link Pattern.Attribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute</em>'.
	 * @see Pattern.Attribute
	 * @generated
	 */
	EClass getAttribute();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Attribute#getAccessright <em>Accessright</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Accessright</em>'.
	 * @see Pattern.Attribute#getAccessright()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Accessright();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Attribute#getAttributetype <em>Attributetype</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attributetype</em>'.
	 * @see Pattern.Attribute#getAttributetype()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Attributetype();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Attribute#getStaticflag <em>Staticflag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Staticflag</em>'.
	 * @see Pattern.Attribute#getStaticflag()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Staticflag();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Attribute#getCiteName <em>Cite Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cite Name</em>'.
	 * @see Pattern.Attribute#getCiteName()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_CiteName();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Attribute#getMulti <em>Multi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multi</em>'.
	 * @see Pattern.Attribute#getMulti()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Multi();

	/**
	 * Returns the meta object for class '{@link Pattern.Parameter <em>Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parameter</em>'.
	 * @see Pattern.Parameter
	 * @generated
	 */
	EClass getParameter();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Parameter#getParameterType <em>Parameter Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Parameter Type</em>'.
	 * @see Pattern.Parameter#getParameterType()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_ParameterType();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Parameter#getCiteName <em>Cite Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cite Name</em>'.
	 * @see Pattern.Parameter#getCiteName()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_CiteName();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Parameter#getMulti <em>Multi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multi</em>'.
	 * @see Pattern.Parameter#getMulti()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_Multi();

	/**
	 * Returns the meta object for class '{@link Pattern.Operation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operation</em>'.
	 * @see Pattern.Operation
	 * @generated
	 */
	EClass getOperation();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Operation#getReturnType <em>Return Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Return Type</em>'.
	 * @see Pattern.Operation#getReturnType()
	 * @see #getOperation()
	 * @generated
	 */
	EAttribute getOperation_ReturnType();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Operation#getAccessright <em>Accessright</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Accessright</em>'.
	 * @see Pattern.Operation#getAccessright()
	 * @see #getOperation()
	 * @generated
	 */
	EAttribute getOperation_Accessright();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Operation#getStaticFlag <em>Static Flag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Static Flag</em>'.
	 * @see Pattern.Operation#getStaticFlag()
	 * @see #getOperation()
	 * @generated
	 */
	EAttribute getOperation_StaticFlag();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Operation#getCiteName <em>Cite Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cite Name</em>'.
	 * @see Pattern.Operation#getCiteName()
	 * @see #getOperation()
	 * @generated
	 */
	EAttribute getOperation_CiteName();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Operation#getMulti <em>Multi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multi</em>'.
	 * @see Pattern.Operation#getMulti()
	 * @see #getOperation()
	 * @generated
	 */
	EAttribute getOperation_Multi();

	/**
	 * Returns the meta object for the containment reference list '{@link Pattern.Operation#getParams <em>Params</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Params</em>'.
	 * @see Pattern.Operation#getParams()
	 * @see #getOperation()
	 * @generated
	 */
	EReference getOperation_Params();

	/**
	 * Returns the meta object for class '{@link Pattern.RoleOf <em>Role Of</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Of</em>'.
	 * @see Pattern.RoleOf
	 * @generated
	 */
	EClass getRoleOf();

	/**
	 * Returns the meta object for the reference '{@link Pattern.RoleOf#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see Pattern.RoleOf#getSource()
	 * @see #getRoleOf()
	 * @generated
	 */
	EReference getRoleOf_Source();

	/**
	 * Returns the meta object for the reference '{@link Pattern.RoleOf#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see Pattern.RoleOf#getTarget()
	 * @see #getRoleOf()
	 * @generated
	 */
	EReference getRoleOf_Target();

	/**
	 * Returns the meta object for class '{@link Pattern.Dependence <em>Dependence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dependence</em>'.
	 * @see Pattern.Dependence
	 * @generated
	 */
	EClass getDependence();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Dependence#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see Pattern.Dependence#getSource()
	 * @see #getDependence()
	 * @generated
	 */
	EReference getDependence_Source();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Dependence#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see Pattern.Dependence#getTarget()
	 * @see #getDependence()
	 * @generated
	 */
	EReference getDependence_Target();

	/**
	 * Returns the meta object for class '{@link Pattern.Aggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aggregation</em>'.
	 * @see Pattern.Aggregation
	 * @generated
	 */
	EClass getAggregation();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Aggregation#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see Pattern.Aggregation#getSource()
	 * @see #getAggregation()
	 * @generated
	 */
	EReference getAggregation_Source();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Aggregation#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see Pattern.Aggregation#getTarget()
	 * @see #getAggregation()
	 * @generated
	 */
	EReference getAggregation_Target();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Aggregation#getRName <em>RName</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>RName</em>'.
	 * @see Pattern.Aggregation#getRName()
	 * @see #getAggregation()
	 * @generated
	 */
	EAttribute getAggregation_RName();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Aggregation#getMulti <em>Multi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multi</em>'.
	 * @see Pattern.Aggregation#getMulti()
	 * @see #getAggregation()
	 * @generated
	 */
	EAttribute getAggregation_Multi();

	/**
	 * Returns the meta object for class '{@link Pattern.Composition <em>Composition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composition</em>'.
	 * @see Pattern.Composition
	 * @generated
	 */
	EClass getComposition();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Composition#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see Pattern.Composition#getSource()
	 * @see #getComposition()
	 * @generated
	 */
	EReference getComposition_Source();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Composition#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see Pattern.Composition#getTarget()
	 * @see #getComposition()
	 * @generated
	 */
	EReference getComposition_Target();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Composition#getRName <em>RName</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>RName</em>'.
	 * @see Pattern.Composition#getRName()
	 * @see #getComposition()
	 * @generated
	 */
	EAttribute getComposition_RName();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.Composition#getMulti <em>Multi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multi</em>'.
	 * @see Pattern.Composition#getMulti()
	 * @see #getComposition()
	 * @generated
	 */
	EAttribute getComposition_Multi();

	/**
	 * Returns the meta object for class '{@link Pattern.DirectedAssociation <em>Directed Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Directed Association</em>'.
	 * @see Pattern.DirectedAssociation
	 * @generated
	 */
	EClass getDirectedAssociation();

	/**
	 * Returns the meta object for the attribute '{@link Pattern.DirectedAssociation#getMulti <em>Multi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Multi</em>'.
	 * @see Pattern.DirectedAssociation#getMulti()
	 * @see #getDirectedAssociation()
	 * @generated
	 */
	EAttribute getDirectedAssociation_Multi();

	/**
	 * Returns the meta object for the reference '{@link Pattern.DirectedAssociation#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see Pattern.DirectedAssociation#getSource()
	 * @see #getDirectedAssociation()
	 * @generated
	 */
	EReference getDirectedAssociation_Source();

	/**
	 * Returns the meta object for the reference '{@link Pattern.DirectedAssociation#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see Pattern.DirectedAssociation#getTarget()
	 * @see #getDirectedAssociation()
	 * @generated
	 */
	EReference getDirectedAssociation_Target();

	/**
	 * Returns the meta object for class '{@link Pattern.Realization <em>Realization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Realization</em>'.
	 * @see Pattern.Realization
	 * @generated
	 */
	EClass getRealization();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Realization#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see Pattern.Realization#getSource()
	 * @see #getRealization()
	 * @generated
	 */
	EReference getRealization_Source();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Realization#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see Pattern.Realization#getTarget()
	 * @see #getRealization()
	 * @generated
	 */
	EReference getRealization_Target();

	/**
	 * Returns the meta object for class '{@link Pattern.Generalization <em>Generalization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Generalization</em>'.
	 * @see Pattern.Generalization
	 * @generated
	 */
	EClass getGeneralization();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Generalization#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see Pattern.Generalization#getSource()
	 * @see #getGeneralization()
	 * @generated
	 */
	EReference getGeneralization_Source();

	/**
	 * Returns the meta object for the reference '{@link Pattern.Generalization#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see Pattern.Generalization#getTarget()
	 * @see #getGeneralization()
	 * @generated
	 */
	EReference getGeneralization_Target();

	/**
	 * Returns the meta object for enum '{@link Pattern.AccessRightsType <em>Access Rights Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Access Rights Type</em>'.
	 * @see Pattern.AccessRightsType
	 * @generated
	 */
	EEnum getAccessRightsType();

	/**
	 * Returns the meta object for enum '{@link Pattern.DataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Data Type</em>'.
	 * @see Pattern.DataType
	 * @generated
	 */
	EEnum getDataType();

	/**
	 * Returns the meta object for enum '{@link Pattern.StaticType <em>Static Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Static Type</em>'.
	 * @see Pattern.StaticType
	 * @generated
	 */
	EEnum getStaticType();

	/**
	 * Returns the meta object for enum '{@link Pattern.AbstractType <em>Abstract Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Abstract Type</em>'.
	 * @see Pattern.AbstractType
	 * @generated
	 */
	EEnum getAbstractType();

	/**
	 * Returns the meta object for enum '{@link Pattern.MultiType <em>Multi Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Multi Type</em>'.
	 * @see Pattern.MultiType
	 * @generated
	 */
	EEnum getMultiType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PatternFactory getPatternFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link Pattern.impl.NameElementImpl <em>Name Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.NameElementImpl
		 * @see Pattern.impl.PatternPackageImpl#getNameElement()
		 * @generated
		 */
		EClass NAME_ELEMENT = eINSTANCE.getNameElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAME_ELEMENT__NAME = eINSTANCE.getNameElement_Name();

		/**
		 * The meta object literal for the '{@link Pattern.impl.DesignPatternImpl <em>Design Pattern</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.DesignPatternImpl
		 * @see Pattern.impl.PatternPackageImpl#getDesignPattern()
		 * @generated
		 */
		EClass DESIGN_PATTERN = eINSTANCE.getDesignPattern();

		/**
		 * The meta object literal for the '<em><b>Roles</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__ROLES = eINSTANCE.getDesignPattern_Roles();

		/**
		 * The meta object literal for the '<em><b>Classes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__CLASSES = eINSTANCE.getDesignPattern_Classes();

		/**
		 * The meta object literal for the '<em><b>Roleofs</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__ROLEOFS = eINSTANCE.getDesignPattern_Roleofs();

		/**
		 * The meta object literal for the '<em><b>Generalizations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__GENERALIZATIONS = eINSTANCE.getDesignPattern_Generalizations();

		/**
		 * The meta object literal for the '<em><b>Dependences</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__DEPENDENCES = eINSTANCE.getDesignPattern_Dependences();

		/**
		 * The meta object literal for the '<em><b>Aggregations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__AGGREGATIONS = eINSTANCE.getDesignPattern_Aggregations();

		/**
		 * The meta object literal for the '<em><b>Compositions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__COMPOSITIONS = eINSTANCE.getDesignPattern_Compositions();

		/**
		 * The meta object literal for the '<em><b>Directedassociations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__DIRECTEDASSOCIATIONS = eINSTANCE.getDesignPattern_Directedassociations();

		/**
		 * The meta object literal for the '<em><b>Realizations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DESIGN_PATTERN__REALIZATIONS = eINSTANCE.getDesignPattern_Realizations();

		/**
		 * The meta object literal for the '{@link Pattern.impl.ClassImpl <em>Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.ClassImpl
		 * @see Pattern.impl.PatternPackageImpl#getClass_()
		 * @generated
		 */
		EClass CLASS = eINSTANCE.getClass_();

		/**
		 * The meta object literal for the '<em><b>New Attribute</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASS__NEW_ATTRIBUTE = eINSTANCE.getClass_NewAttribute();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__ATTRIBUTES = eINSTANCE.getClass_Attributes();

		/**
		 * The meta object literal for the '<em><b>Operations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__OPERATIONS = eINSTANCE.getClass_Operations();

		/**
		 * The meta object literal for the '<em><b>Role Te</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__ROLE_TE = eINSTANCE.getClass_RoleTe();

		/**
		 * The meta object literal for the '{@link Pattern.impl.RoleElementImpl <em>Role Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.RoleElementImpl
		 * @see Pattern.impl.PatternPackageImpl#getRoleElement()
		 * @generated
		 */
		EClass ROLE_ELEMENT = eINSTANCE.getRoleElement();

		/**
		 * The meta object literal for the '<em><b>Role From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_ELEMENT__ROLE_FROM = eINSTANCE.getRoleElement_RoleFrom();

		/**
		 * The meta object literal for the '<em><b>Realization To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_ELEMENT__REALIZATION_TO = eINSTANCE.getRoleElement_RealizationTo();

		/**
		 * The meta object literal for the '<em><b>Dependence From</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_ELEMENT__DEPENDENCE_FROM = eINSTANCE.getRoleElement_DependenceFrom();

		/**
		 * The meta object literal for the '<em><b>Aggregation From</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_ELEMENT__AGGREGATION_FROM = eINSTANCE.getRoleElement_AggregationFrom();

		/**
		 * The meta object literal for the '<em><b>Composition From</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_ELEMENT__COMPOSITION_FROM = eINSTANCE.getRoleElement_CompositionFrom();

		/**
		 * The meta object literal for the '<em><b>Directedassociation From</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM = eINSTANCE.getRoleElement_DirectedassociationFrom();

		/**
		 * The meta object literal for the '{@link Pattern.impl.RoleImpl <em>Role</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.RoleImpl
		 * @see Pattern.impl.PatternPackageImpl#getRole()
		 * @generated
		 */
		EClass ROLE = eINSTANCE.getRole();

		/**
		 * The meta object literal for the '<em><b>Abstractflag</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROLE__ABSTRACTFLAG = eINSTANCE.getRole_Abstractflag();

		/**
		 * The meta object literal for the '<em><b>Generalization To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__GENERALIZATION_TO = eINSTANCE.getRole_GeneralizationTo();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__ATTRIBUTES = eINSTANCE.getRole_Attributes();

		/**
		 * The meta object literal for the '<em><b>Operations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__OPERATIONS = eINSTANCE.getRole_Operations();

		/**
		 * The meta object literal for the '<em><b>Dependence To</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__DEPENDENCE_TO = eINSTANCE.getRole_DependenceTo();

		/**
		 * The meta object literal for the '<em><b>Aggregation To</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__AGGREGATION_TO = eINSTANCE.getRole_AggregationTo();

		/**
		 * The meta object literal for the '<em><b>Composition To</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__COMPOSITION_TO = eINSTANCE.getRole_CompositionTo();

		/**
		 * The meta object literal for the '<em><b>Directedassociation To</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__DIRECTEDASSOCIATION_TO = eINSTANCE.getRole_DirectedassociationTo();

		/**
		 * The meta object literal for the '<em><b>Generalization From</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE__GENERALIZATION_FROM = eINSTANCE.getRole_GeneralizationFrom();

		/**
		 * The meta object literal for the '{@link Pattern.impl.RoleInterfaceImpl <em>Role Interface</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.RoleInterfaceImpl
		 * @see Pattern.impl.PatternPackageImpl#getRoleInterface()
		 * @generated
		 */
		EClass ROLE_INTERFACE = eINSTANCE.getRoleInterface();

		/**
		 * The meta object literal for the '<em><b>Operations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_INTERFACE__OPERATIONS = eINSTANCE.getRoleInterface_Operations();

		/**
		 * The meta object literal for the '<em><b>Realization From</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_INTERFACE__REALIZATION_FROM = eINSTANCE.getRoleInterface_RealizationFrom();

		/**
		 * The meta object literal for the '{@link Pattern.impl.AttributeImpl <em>Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.AttributeImpl
		 * @see Pattern.impl.PatternPackageImpl#getAttribute()
		 * @generated
		 */
		EClass ATTRIBUTE = eINSTANCE.getAttribute();

		/**
		 * The meta object literal for the '<em><b>Accessright</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__ACCESSRIGHT = eINSTANCE.getAttribute_Accessright();

		/**
		 * The meta object literal for the '<em><b>Attributetype</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__ATTRIBUTETYPE = eINSTANCE.getAttribute_Attributetype();

		/**
		 * The meta object literal for the '<em><b>Staticflag</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__STATICFLAG = eINSTANCE.getAttribute_Staticflag();

		/**
		 * The meta object literal for the '<em><b>Cite Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__CITE_NAME = eINSTANCE.getAttribute_CiteName();

		/**
		 * The meta object literal for the '<em><b>Multi</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__MULTI = eINSTANCE.getAttribute_Multi();

		/**
		 * The meta object literal for the '{@link Pattern.impl.ParameterImpl <em>Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.ParameterImpl
		 * @see Pattern.impl.PatternPackageImpl#getParameter()
		 * @generated
		 */
		EClass PARAMETER = eINSTANCE.getParameter();

		/**
		 * The meta object literal for the '<em><b>Parameter Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__PARAMETER_TYPE = eINSTANCE.getParameter_ParameterType();

		/**
		 * The meta object literal for the '<em><b>Cite Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__CITE_NAME = eINSTANCE.getParameter_CiteName();

		/**
		 * The meta object literal for the '<em><b>Multi</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__MULTI = eINSTANCE.getParameter_Multi();

		/**
		 * The meta object literal for the '{@link Pattern.impl.OperationImpl <em>Operation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.OperationImpl
		 * @see Pattern.impl.PatternPackageImpl#getOperation()
		 * @generated
		 */
		EClass OPERATION = eINSTANCE.getOperation();

		/**
		 * The meta object literal for the '<em><b>Return Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATION__RETURN_TYPE = eINSTANCE.getOperation_ReturnType();

		/**
		 * The meta object literal for the '<em><b>Accessright</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATION__ACCESSRIGHT = eINSTANCE.getOperation_Accessright();

		/**
		 * The meta object literal for the '<em><b>Static Flag</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATION__STATIC_FLAG = eINSTANCE.getOperation_StaticFlag();

		/**
		 * The meta object literal for the '<em><b>Cite Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATION__CITE_NAME = eINSTANCE.getOperation_CiteName();

		/**
		 * The meta object literal for the '<em><b>Multi</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPERATION__MULTI = eINSTANCE.getOperation_Multi();

		/**
		 * The meta object literal for the '<em><b>Params</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OPERATION__PARAMS = eINSTANCE.getOperation_Params();

		/**
		 * The meta object literal for the '{@link Pattern.impl.RoleOfImpl <em>Role Of</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.RoleOfImpl
		 * @see Pattern.impl.PatternPackageImpl#getRoleOf()
		 * @generated
		 */
		EClass ROLE_OF = eINSTANCE.getRoleOf();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_OF__SOURCE = eINSTANCE.getRoleOf_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROLE_OF__TARGET = eINSTANCE.getRoleOf_Target();

		/**
		 * The meta object literal for the '{@link Pattern.impl.DependenceImpl <em>Dependence</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.DependenceImpl
		 * @see Pattern.impl.PatternPackageImpl#getDependence()
		 * @generated
		 */
		EClass DEPENDENCE = eINSTANCE.getDependence();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCE__SOURCE = eINSTANCE.getDependence_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPENDENCE__TARGET = eINSTANCE.getDependence_Target();

		/**
		 * The meta object literal for the '{@link Pattern.impl.AggregationImpl <em>Aggregation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.AggregationImpl
		 * @see Pattern.impl.PatternPackageImpl#getAggregation()
		 * @generated
		 */
		EClass AGGREGATION = eINSTANCE.getAggregation();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGGREGATION__SOURCE = eINSTANCE.getAggregation_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGGREGATION__TARGET = eINSTANCE.getAggregation_Target();

		/**
		 * The meta object literal for the '<em><b>RName</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATION__RNAME = eINSTANCE.getAggregation_RName();

		/**
		 * The meta object literal for the '<em><b>Multi</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGGREGATION__MULTI = eINSTANCE.getAggregation_Multi();

		/**
		 * The meta object literal for the '{@link Pattern.impl.CompositionImpl <em>Composition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.CompositionImpl
		 * @see Pattern.impl.PatternPackageImpl#getComposition()
		 * @generated
		 */
		EClass COMPOSITION = eINSTANCE.getComposition();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSITION__SOURCE = eINSTANCE.getComposition_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSITION__TARGET = eINSTANCE.getComposition_Target();

		/**
		 * The meta object literal for the '<em><b>RName</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPOSITION__RNAME = eINSTANCE.getComposition_RName();

		/**
		 * The meta object literal for the '<em><b>Multi</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPOSITION__MULTI = eINSTANCE.getComposition_Multi();

		/**
		 * The meta object literal for the '{@link Pattern.impl.DirectedAssociationImpl <em>Directed Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.DirectedAssociationImpl
		 * @see Pattern.impl.PatternPackageImpl#getDirectedAssociation()
		 * @generated
		 */
		EClass DIRECTED_ASSOCIATION = eINSTANCE.getDirectedAssociation();

		/**
		 * The meta object literal for the '<em><b>Multi</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIRECTED_ASSOCIATION__MULTI = eINSTANCE.getDirectedAssociation_Multi();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIRECTED_ASSOCIATION__SOURCE = eINSTANCE.getDirectedAssociation_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIRECTED_ASSOCIATION__TARGET = eINSTANCE.getDirectedAssociation_Target();

		/**
		 * The meta object literal for the '{@link Pattern.impl.RealizationImpl <em>Realization</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.RealizationImpl
		 * @see Pattern.impl.PatternPackageImpl#getRealization()
		 * @generated
		 */
		EClass REALIZATION = eINSTANCE.getRealization();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REALIZATION__SOURCE = eINSTANCE.getRealization_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REALIZATION__TARGET = eINSTANCE.getRealization_Target();

		/**
		 * The meta object literal for the '{@link Pattern.impl.GeneralizationImpl <em>Generalization</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.impl.GeneralizationImpl
		 * @see Pattern.impl.PatternPackageImpl#getGeneralization()
		 * @generated
		 */
		EClass GENERALIZATION = eINSTANCE.getGeneralization();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GENERALIZATION__SOURCE = eINSTANCE.getGeneralization_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GENERALIZATION__TARGET = eINSTANCE.getGeneralization_Target();

		/**
		 * The meta object literal for the '{@link Pattern.AccessRightsType <em>Access Rights Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.AccessRightsType
		 * @see Pattern.impl.PatternPackageImpl#getAccessRightsType()
		 * @generated
		 */
		EEnum ACCESS_RIGHTS_TYPE = eINSTANCE.getAccessRightsType();

		/**
		 * The meta object literal for the '{@link Pattern.DataType <em>Data Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.DataType
		 * @see Pattern.impl.PatternPackageImpl#getDataType()
		 * @generated
		 */
		EEnum DATA_TYPE = eINSTANCE.getDataType();

		/**
		 * The meta object literal for the '{@link Pattern.StaticType <em>Static Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.StaticType
		 * @see Pattern.impl.PatternPackageImpl#getStaticType()
		 * @generated
		 */
		EEnum STATIC_TYPE = eINSTANCE.getStaticType();

		/**
		 * The meta object literal for the '{@link Pattern.AbstractType <em>Abstract Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.AbstractType
		 * @see Pattern.impl.PatternPackageImpl#getAbstractType()
		 * @generated
		 */
		EEnum ABSTRACT_TYPE = eINSTANCE.getAbstractType();

		/**
		 * The meta object literal for the '{@link Pattern.MultiType <em>Multi Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Pattern.MultiType
		 * @see Pattern.impl.PatternPackageImpl#getMultiType()
		 * @generated
		 */
		EEnum MULTI_TYPE = eINSTANCE.getMultiType();

	}

} //PatternPackage
