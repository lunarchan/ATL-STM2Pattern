/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Realization</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Realization#getSource <em>Source</em>}</li>
 *   <li>{@link Pattern.Realization#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getRealization()
 * @model
 * @generated
 */
public interface Realization extends NameElement {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(RoleElement)
	 * @see Pattern.PatternPackage#getRealization_Source()
	 * @model required="true"
	 * @generated
	 */
	RoleElement getSource();

	/**
	 * Sets the value of the '{@link Pattern.Realization#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(RoleElement value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(RoleInterface)
	 * @see Pattern.PatternPackage#getRealization_Target()
	 * @model required="true"
	 * @generated
	 */
	RoleInterface getTarget();

	/**
	 * Sets the value of the '{@link Pattern.Realization#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(RoleInterface value);

} // Realization
