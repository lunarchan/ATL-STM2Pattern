/**
 */
package Pattern;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.Role#getAbstractflag <em>Abstractflag</em>}</li>
 *   <li>{@link Pattern.Role#getGeneralizationTo <em>Generalization To</em>}</li>
 *   <li>{@link Pattern.Role#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link Pattern.Role#getOperations <em>Operations</em>}</li>
 *   <li>{@link Pattern.Role#getDependenceTo <em>Dependence To</em>}</li>
 *   <li>{@link Pattern.Role#getAggregationTo <em>Aggregation To</em>}</li>
 *   <li>{@link Pattern.Role#getCompositionTo <em>Composition To</em>}</li>
 *   <li>{@link Pattern.Role#getDirectedassociationTo <em>Directedassociation To</em>}</li>
 *   <li>{@link Pattern.Role#getGeneralizationFrom <em>Generalization From</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getRole()
 * @model
 * @generated
 */
public interface Role extends RoleElement {
	/**
	 * Returns the value of the '<em><b>Abstractflag</b></em>' attribute.
	 * The literals are from the enumeration {@link Pattern.AbstractType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Abstractflag</em>' attribute.
	 * @see Pattern.AbstractType
	 * @see #setAbstractflag(AbstractType)
	 * @see Pattern.PatternPackage#getRole_Abstractflag()
	 * @model
	 * @generated
	 */
	AbstractType getAbstractflag();

	/**
	 * Sets the value of the '{@link Pattern.Role#getAbstractflag <em>Abstractflag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Abstractflag</em>' attribute.
	 * @see Pattern.AbstractType
	 * @see #getAbstractflag()
	 * @generated
	 */
	void setAbstractflag(AbstractType value);

	/**
	 * Returns the value of the '<em><b>Generalization To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Generalization To</em>' reference.
	 * @see #setGeneralizationTo(Generalization)
	 * @see Pattern.PatternPackage#getRole_GeneralizationTo()
	 * @model
	 * @generated
	 */
	Generalization getGeneralizationTo();

	/**
	 * Sets the value of the '{@link Pattern.Role#getGeneralizationTo <em>Generalization To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Generalization To</em>' reference.
	 * @see #getGeneralizationTo()
	 * @generated
	 */
	void setGeneralizationTo(Generalization value);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Attribute}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRole_Attributes()
	 * @model containment="true"
	 * @generated
	 */
	EList<Attribute> getAttributes();

	/**
	 * Returns the value of the '<em><b>Operations</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Operation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operations</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRole_Operations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operation> getOperations();

	/**
	 * Returns the value of the '<em><b>Dependence To</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Dependence}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependence To</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRole_DependenceTo()
	 * @model containment="true"
	 * @generated
	 */
	EList<Dependence> getDependenceTo();

	/**
	 * Returns the value of the '<em><b>Aggregation To</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Aggregation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregation To</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRole_AggregationTo()
	 * @model containment="true"
	 * @generated
	 */
	EList<Aggregation> getAggregationTo();

	/**
	 * Returns the value of the '<em><b>Composition To</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Composition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Composition To</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRole_CompositionTo()
	 * @model containment="true"
	 * @generated
	 */
	EList<Composition> getCompositionTo();

	/**
	 * Returns the value of the '<em><b>Directedassociation To</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.DirectedAssociation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Directedassociation To</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRole_DirectedassociationTo()
	 * @model containment="true"
	 * @generated
	 */
	EList<DirectedAssociation> getDirectedassociationTo();

	/**
	 * Returns the value of the '<em><b>Generalization From</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Generalization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Generalization From</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRole_GeneralizationFrom()
	 * @model containment="true"
	 * @generated
	 */
	EList<Generalization> getGeneralizationFrom();

} // Role
