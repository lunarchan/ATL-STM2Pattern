/**
 */
package Pattern;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.RoleElement#getRoleFrom <em>Role From</em>}</li>
 *   <li>{@link Pattern.RoleElement#getRealizationTo <em>Realization To</em>}</li>
 *   <li>{@link Pattern.RoleElement#getDependenceFrom <em>Dependence From</em>}</li>
 *   <li>{@link Pattern.RoleElement#getAggregationFrom <em>Aggregation From</em>}</li>
 *   <li>{@link Pattern.RoleElement#getCompositionFrom <em>Composition From</em>}</li>
 *   <li>{@link Pattern.RoleElement#getDirectedassociationFrom <em>Directedassociation From</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getRoleElement()
 * @model
 * @generated
 */
public interface RoleElement extends NameElement {
	/**
	 * Returns the value of the '<em><b>Role From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role From</em>' reference.
	 * @see #setRoleFrom(RoleOf)
	 * @see Pattern.PatternPackage#getRoleElement_RoleFrom()
	 * @model
	 * @generated
	 */
	RoleOf getRoleFrom();

	/**
	 * Sets the value of the '{@link Pattern.RoleElement#getRoleFrom <em>Role From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Role From</em>' reference.
	 * @see #getRoleFrom()
	 * @generated
	 */
	void setRoleFrom(RoleOf value);

	/**
	 * Returns the value of the '<em><b>Realization To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Realization To</em>' reference.
	 * @see #setRealizationTo(Realization)
	 * @see Pattern.PatternPackage#getRoleElement_RealizationTo()
	 * @model
	 * @generated
	 */
	Realization getRealizationTo();

	/**
	 * Sets the value of the '{@link Pattern.RoleElement#getRealizationTo <em>Realization To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Realization To</em>' reference.
	 * @see #getRealizationTo()
	 * @generated
	 */
	void setRealizationTo(Realization value);

	/**
	 * Returns the value of the '<em><b>Dependence From</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Dependence}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependence From</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRoleElement_DependenceFrom()
	 * @model containment="true"
	 * @generated
	 */
	EList<Dependence> getDependenceFrom();

	/**
	 * Returns the value of the '<em><b>Aggregation From</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Aggregation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregation From</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRoleElement_AggregationFrom()
	 * @model containment="true"
	 * @generated
	 */
	EList<Aggregation> getAggregationFrom();

	/**
	 * Returns the value of the '<em><b>Composition From</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Composition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Composition From</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRoleElement_CompositionFrom()
	 * @model containment="true"
	 * @generated
	 */
	EList<Composition> getCompositionFrom();

	/**
	 * Returns the value of the '<em><b>Directedassociation From</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.DirectedAssociation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Directedassociation From</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRoleElement_DirectedassociationFrom()
	 * @model containment="true"
	 * @generated
	 */
	EList<DirectedAssociation> getDirectedassociationFrom();

} // RoleElement
