/**
 */
package Pattern;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.RoleInterface#getOperations <em>Operations</em>}</li>
 *   <li>{@link Pattern.RoleInterface#getRealizationFrom <em>Realization From</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getRoleInterface()
 * @model
 * @generated
 */
public interface RoleInterface extends RoleElement {
	/**
	 * Returns the value of the '<em><b>Operations</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Operation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operations</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRoleInterface_Operations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Operation> getOperations();

	/**
	 * Returns the value of the '<em><b>Realization From</b></em>' containment reference list.
	 * The list contents are of type {@link Pattern.Realization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Realization From</em>' containment reference list.
	 * @see Pattern.PatternPackage#getRoleInterface_RealizationFrom()
	 * @model containment="true"
	 * @generated
	 */
	EList<Realization> getRealizationFrom();

} // RoleInterface
