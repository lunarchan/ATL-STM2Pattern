/**
 */
package Pattern;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Of</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Pattern.RoleOf#getSource <em>Source</em>}</li>
 *   <li>{@link Pattern.RoleOf#getTarget <em>Target</em>}</li>
 * </ul>
 *
 * @see Pattern.PatternPackage#getRoleOf()
 * @model
 * @generated
 */
public interface RoleOf extends NameElement {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Pattern.Class)
	 * @see Pattern.PatternPackage#getRoleOf_Source()
	 * @model required="true"
	 * @generated
	 */
	Pattern.Class getSource();

	/**
	 * Sets the value of the '{@link Pattern.RoleOf#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Pattern.Class value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(RoleElement)
	 * @see Pattern.PatternPackage#getRoleOf_Target()
	 * @model required="true"
	 * @generated
	 */
	RoleElement getTarget();

	/**
	 * Sets the value of the '{@link Pattern.RoleOf#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(RoleElement value);

} // RoleOf
