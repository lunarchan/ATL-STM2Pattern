/**
 */
package Pattern.impl;

import Pattern.Aggregation;
import Pattern.MultiType;
import Pattern.PatternPackage;
import Pattern.Role;
import Pattern.RoleInterface;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Aggregation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.AggregationImpl#getSource <em>Source</em>}</li>
 *   <li>{@link Pattern.impl.AggregationImpl#getTarget <em>Target</em>}</li>
 *   <li>{@link Pattern.impl.AggregationImpl#getRName <em>RName</em>}</li>
 *   <li>{@link Pattern.impl.AggregationImpl#getMulti <em>Multi</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AggregationImpl extends NameElementImpl implements Aggregation {
	/**
	 * The cached value of the '{@link #getSource() <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected Role source;

	/**
	 * The cached value of the '{@link #getTarget() <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget()
	 * @generated
	 * @ordered
	 */
	protected RoleInterface target;

	/**
	 * The default value of the '{@link #getRName() <em>RName</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRName()
	 * @generated
	 * @ordered
	 */
	protected static final String RNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRName() <em>RName</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRName()
	 * @generated
	 * @ordered
	 */
	protected String rName = RNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected static final MultiType MULTI_EDEFAULT = MultiType.YES;

	/**
	 * The cached value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected MultiType multi = MULTI_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AggregationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.AGGREGATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Role getSource() {
		if (source != null && source.eIsProxy()) {
			InternalEObject oldSource = (InternalEObject)source;
			source = (Role)eResolveProxy(oldSource);
			if (source != oldSource) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PatternPackage.AGGREGATION__SOURCE, oldSource, source));
			}
		}
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Role basicGetSource() {
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSource(Role newSource) {
		Role oldSource = source;
		source = newSource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.AGGREGATION__SOURCE, oldSource, source));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleInterface getTarget() {
		if (target != null && target.eIsProxy()) {
			InternalEObject oldTarget = (InternalEObject)target;
			target = (RoleInterface)eResolveProxy(oldTarget);
			if (target != oldTarget) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PatternPackage.AGGREGATION__TARGET, oldTarget, target));
			}
		}
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleInterface basicGetTarget() {
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTarget(RoleInterface newTarget) {
		RoleInterface oldTarget = target;
		target = newTarget;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.AGGREGATION__TARGET, oldTarget, target));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getRName() {
		return rName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRName(String newRName) {
		String oldRName = rName;
		rName = newRName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.AGGREGATION__RNAME, oldRName, rName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MultiType getMulti() {
		return multi;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMulti(MultiType newMulti) {
		MultiType oldMulti = multi;
		multi = newMulti == null ? MULTI_EDEFAULT : newMulti;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.AGGREGATION__MULTI, oldMulti, multi));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.AGGREGATION__SOURCE:
				if (resolve) return getSource();
				return basicGetSource();
			case PatternPackage.AGGREGATION__TARGET:
				if (resolve) return getTarget();
				return basicGetTarget();
			case PatternPackage.AGGREGATION__RNAME:
				return getRName();
			case PatternPackage.AGGREGATION__MULTI:
				return getMulti();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.AGGREGATION__SOURCE:
				setSource((Role)newValue);
				return;
			case PatternPackage.AGGREGATION__TARGET:
				setTarget((RoleInterface)newValue);
				return;
			case PatternPackage.AGGREGATION__RNAME:
				setRName((String)newValue);
				return;
			case PatternPackage.AGGREGATION__MULTI:
				setMulti((MultiType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.AGGREGATION__SOURCE:
				setSource((Role)null);
				return;
			case PatternPackage.AGGREGATION__TARGET:
				setTarget((RoleInterface)null);
				return;
			case PatternPackage.AGGREGATION__RNAME:
				setRName(RNAME_EDEFAULT);
				return;
			case PatternPackage.AGGREGATION__MULTI:
				setMulti(MULTI_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.AGGREGATION__SOURCE:
				return source != null;
			case PatternPackage.AGGREGATION__TARGET:
				return target != null;
			case PatternPackage.AGGREGATION__RNAME:
				return RNAME_EDEFAULT == null ? rName != null : !RNAME_EDEFAULT.equals(rName);
			case PatternPackage.AGGREGATION__MULTI:
				return multi != MULTI_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (rName: ");
		result.append(rName);
		result.append(", multi: ");
		result.append(multi);
		result.append(')');
		return result.toString();
	}

} //AggregationImpl
