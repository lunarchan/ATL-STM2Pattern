/**
 */
package Pattern.impl;

import Pattern.AccessRightsType;
import Pattern.Attribute;
import Pattern.DataType;
import Pattern.MultiType;
import Pattern.PatternPackage;
import Pattern.StaticType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.AttributeImpl#getAccessright <em>Accessright</em>}</li>
 *   <li>{@link Pattern.impl.AttributeImpl#getAttributetype <em>Attributetype</em>}</li>
 *   <li>{@link Pattern.impl.AttributeImpl#getStaticflag <em>Staticflag</em>}</li>
 *   <li>{@link Pattern.impl.AttributeImpl#getCiteName <em>Cite Name</em>}</li>
 *   <li>{@link Pattern.impl.AttributeImpl#getMulti <em>Multi</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttributeImpl extends NameElementImpl implements Attribute {
	/**
	 * The default value of the '{@link #getAccessright() <em>Accessright</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessright()
	 * @generated
	 * @ordered
	 */
	protected static final AccessRightsType ACCESSRIGHT_EDEFAULT = AccessRightsType.PRIVATE;

	/**
	 * The cached value of the '{@link #getAccessright() <em>Accessright</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessright()
	 * @generated
	 * @ordered
	 */
	protected AccessRightsType accessright = ACCESSRIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #getAttributetype() <em>Attributetype</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributetype()
	 * @generated
	 * @ordered
	 */
	protected static final DataType ATTRIBUTETYPE_EDEFAULT = DataType.INT;

	/**
	 * The cached value of the '{@link #getAttributetype() <em>Attributetype</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributetype()
	 * @generated
	 * @ordered
	 */
	protected DataType attributetype = ATTRIBUTETYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getStaticflag() <em>Staticflag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticflag()
	 * @generated
	 * @ordered
	 */
	protected static final StaticType STATICFLAG_EDEFAULT = StaticType.YES;

	/**
	 * The cached value of the '{@link #getStaticflag() <em>Staticflag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticflag()
	 * @generated
	 * @ordered
	 */
	protected StaticType staticflag = STATICFLAG_EDEFAULT;

	/**
	 * The default value of the '{@link #getCiteName() <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCiteName()
	 * @generated
	 * @ordered
	 */
	protected static final String CITE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCiteName() <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCiteName()
	 * @generated
	 * @ordered
	 */
	protected String citeName = CITE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected static final MultiType MULTI_EDEFAULT = MultiType.YES;

	/**
	 * The cached value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected MultiType multi = MULTI_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttributeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.ATTRIBUTE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AccessRightsType getAccessright() {
		return accessright;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAccessright(AccessRightsType newAccessright) {
		AccessRightsType oldAccessright = accessright;
		accessright = newAccessright == null ? ACCESSRIGHT_EDEFAULT : newAccessright;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ATTRIBUTE__ACCESSRIGHT, oldAccessright, accessright));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DataType getAttributetype() {
		return attributetype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttributetype(DataType newAttributetype) {
		DataType oldAttributetype = attributetype;
		attributetype = newAttributetype == null ? ATTRIBUTETYPE_EDEFAULT : newAttributetype;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ATTRIBUTE__ATTRIBUTETYPE, oldAttributetype, attributetype));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StaticType getStaticflag() {
		return staticflag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStaticflag(StaticType newStaticflag) {
		StaticType oldStaticflag = staticflag;
		staticflag = newStaticflag == null ? STATICFLAG_EDEFAULT : newStaticflag;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ATTRIBUTE__STATICFLAG, oldStaticflag, staticflag));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCiteName() {
		return citeName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCiteName(String newCiteName) {
		String oldCiteName = citeName;
		citeName = newCiteName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ATTRIBUTE__CITE_NAME, oldCiteName, citeName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MultiType getMulti() {
		return multi;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMulti(MultiType newMulti) {
		MultiType oldMulti = multi;
		multi = newMulti == null ? MULTI_EDEFAULT : newMulti;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ATTRIBUTE__MULTI, oldMulti, multi));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.ATTRIBUTE__ACCESSRIGHT:
				return getAccessright();
			case PatternPackage.ATTRIBUTE__ATTRIBUTETYPE:
				return getAttributetype();
			case PatternPackage.ATTRIBUTE__STATICFLAG:
				return getStaticflag();
			case PatternPackage.ATTRIBUTE__CITE_NAME:
				return getCiteName();
			case PatternPackage.ATTRIBUTE__MULTI:
				return getMulti();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.ATTRIBUTE__ACCESSRIGHT:
				setAccessright((AccessRightsType)newValue);
				return;
			case PatternPackage.ATTRIBUTE__ATTRIBUTETYPE:
				setAttributetype((DataType)newValue);
				return;
			case PatternPackage.ATTRIBUTE__STATICFLAG:
				setStaticflag((StaticType)newValue);
				return;
			case PatternPackage.ATTRIBUTE__CITE_NAME:
				setCiteName((String)newValue);
				return;
			case PatternPackage.ATTRIBUTE__MULTI:
				setMulti((MultiType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.ATTRIBUTE__ACCESSRIGHT:
				setAccessright(ACCESSRIGHT_EDEFAULT);
				return;
			case PatternPackage.ATTRIBUTE__ATTRIBUTETYPE:
				setAttributetype(ATTRIBUTETYPE_EDEFAULT);
				return;
			case PatternPackage.ATTRIBUTE__STATICFLAG:
				setStaticflag(STATICFLAG_EDEFAULT);
				return;
			case PatternPackage.ATTRIBUTE__CITE_NAME:
				setCiteName(CITE_NAME_EDEFAULT);
				return;
			case PatternPackage.ATTRIBUTE__MULTI:
				setMulti(MULTI_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.ATTRIBUTE__ACCESSRIGHT:
				return accessright != ACCESSRIGHT_EDEFAULT;
			case PatternPackage.ATTRIBUTE__ATTRIBUTETYPE:
				return attributetype != ATTRIBUTETYPE_EDEFAULT;
			case PatternPackage.ATTRIBUTE__STATICFLAG:
				return staticflag != STATICFLAG_EDEFAULT;
			case PatternPackage.ATTRIBUTE__CITE_NAME:
				return CITE_NAME_EDEFAULT == null ? citeName != null : !CITE_NAME_EDEFAULT.equals(citeName);
			case PatternPackage.ATTRIBUTE__MULTI:
				return multi != MULTI_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (accessright: ");
		result.append(accessright);
		result.append(", attributetype: ");
		result.append(attributetype);
		result.append(", staticflag: ");
		result.append(staticflag);
		result.append(", citeName: ");
		result.append(citeName);
		result.append(", multi: ");
		result.append(multi);
		result.append(')');
		return result.toString();
	}

} //AttributeImpl
