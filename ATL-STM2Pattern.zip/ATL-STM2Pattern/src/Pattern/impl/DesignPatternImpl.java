/**
 */
package Pattern.impl;

import Pattern.Aggregation;
import Pattern.Composition;
import Pattern.Dependence;
import Pattern.DesignPattern;
import Pattern.DirectedAssociation;
import Pattern.Generalization;
import Pattern.PatternPackage;
import Pattern.Realization;
import Pattern.RoleElement;
import Pattern.RoleOf;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Design Pattern</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getRoles <em>Roles</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getClasses <em>Classes</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getRoleofs <em>Roleofs</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getGeneralizations <em>Generalizations</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getDependences <em>Dependences</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getAggregations <em>Aggregations</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getCompositions <em>Compositions</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getDirectedassociations <em>Directedassociations</em>}</li>
 *   <li>{@link Pattern.impl.DesignPatternImpl#getRealizations <em>Realizations</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DesignPatternImpl extends NameElementImpl implements DesignPattern {
	/**
	 * The cached value of the '{@link #getRoles() <em>Roles</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoles()
	 * @generated
	 * @ordered
	 */
	protected EList<RoleElement> roles;

	/**
	 * The cached value of the '{@link #getClasses() <em>Classes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClasses()
	 * @generated
	 * @ordered
	 */
	protected EList<Pattern.Class> classes;

	/**
	 * The cached value of the '{@link #getRoleofs() <em>Roleofs</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoleofs()
	 * @generated
	 * @ordered
	 */
	protected EList<RoleOf> roleofs;

	/**
	 * The cached value of the '{@link #getGeneralizations() <em>Generalizations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneralizations()
	 * @generated
	 * @ordered
	 */
	protected EList<Generalization> generalizations;

	/**
	 * The cached value of the '{@link #getDependences() <em>Dependences</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDependences()
	 * @generated
	 * @ordered
	 */
	protected EList<Dependence> dependences;

	/**
	 * The cached value of the '{@link #getAggregations() <em>Aggregations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregations()
	 * @generated
	 * @ordered
	 */
	protected EList<Aggregation> aggregations;

	/**
	 * The cached value of the '{@link #getCompositions() <em>Compositions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompositions()
	 * @generated
	 * @ordered
	 */
	protected EList<Composition> compositions;

	/**
	 * The cached value of the '{@link #getDirectedassociations() <em>Directedassociations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDirectedassociations()
	 * @generated
	 * @ordered
	 */
	protected EList<DirectedAssociation> directedassociations;

	/**
	 * The cached value of the '{@link #getRealizations() <em>Realizations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRealizations()
	 * @generated
	 * @ordered
	 */
	protected EList<Realization> realizations;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DesignPatternImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.DESIGN_PATTERN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<RoleElement> getRoles() {
		if (roles == null) {
			roles = new EObjectContainmentEList<RoleElement>(RoleElement.class, this, PatternPackage.DESIGN_PATTERN__ROLES);
		}
		return roles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Pattern.Class> getClasses() {
		if (classes == null) {
			classes = new EObjectContainmentEList<Pattern.Class>(Pattern.Class.class, this, PatternPackage.DESIGN_PATTERN__CLASSES);
		}
		return classes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<RoleOf> getRoleofs() {
		if (roleofs == null) {
			roleofs = new EObjectContainmentEList<RoleOf>(RoleOf.class, this, PatternPackage.DESIGN_PATTERN__ROLEOFS);
		}
		return roleofs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Generalization> getGeneralizations() {
		if (generalizations == null) {
			generalizations = new EObjectContainmentEList<Generalization>(Generalization.class, this, PatternPackage.DESIGN_PATTERN__GENERALIZATIONS);
		}
		return generalizations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Dependence> getDependences() {
		if (dependences == null) {
			dependences = new EObjectContainmentEList<Dependence>(Dependence.class, this, PatternPackage.DESIGN_PATTERN__DEPENDENCES);
		}
		return dependences;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Aggregation> getAggregations() {
		if (aggregations == null) {
			aggregations = new EObjectContainmentEList<Aggregation>(Aggregation.class, this, PatternPackage.DESIGN_PATTERN__AGGREGATIONS);
		}
		return aggregations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Composition> getCompositions() {
		if (compositions == null) {
			compositions = new EObjectContainmentEList<Composition>(Composition.class, this, PatternPackage.DESIGN_PATTERN__COMPOSITIONS);
		}
		return compositions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DirectedAssociation> getDirectedassociations() {
		if (directedassociations == null) {
			directedassociations = new EObjectContainmentEList<DirectedAssociation>(DirectedAssociation.class, this, PatternPackage.DESIGN_PATTERN__DIRECTEDASSOCIATIONS);
		}
		return directedassociations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Realization> getRealizations() {
		if (realizations == null) {
			realizations = new EObjectContainmentEList<Realization>(Realization.class, this, PatternPackage.DESIGN_PATTERN__REALIZATIONS);
		}
		return realizations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PatternPackage.DESIGN_PATTERN__ROLES:
				return ((InternalEList<?>)getRoles()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__CLASSES:
				return ((InternalEList<?>)getClasses()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__ROLEOFS:
				return ((InternalEList<?>)getRoleofs()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__GENERALIZATIONS:
				return ((InternalEList<?>)getGeneralizations()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__DEPENDENCES:
				return ((InternalEList<?>)getDependences()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__AGGREGATIONS:
				return ((InternalEList<?>)getAggregations()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__COMPOSITIONS:
				return ((InternalEList<?>)getCompositions()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__DIRECTEDASSOCIATIONS:
				return ((InternalEList<?>)getDirectedassociations()).basicRemove(otherEnd, msgs);
			case PatternPackage.DESIGN_PATTERN__REALIZATIONS:
				return ((InternalEList<?>)getRealizations()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.DESIGN_PATTERN__ROLES:
				return getRoles();
			case PatternPackage.DESIGN_PATTERN__CLASSES:
				return getClasses();
			case PatternPackage.DESIGN_PATTERN__ROLEOFS:
				return getRoleofs();
			case PatternPackage.DESIGN_PATTERN__GENERALIZATIONS:
				return getGeneralizations();
			case PatternPackage.DESIGN_PATTERN__DEPENDENCES:
				return getDependences();
			case PatternPackage.DESIGN_PATTERN__AGGREGATIONS:
				return getAggregations();
			case PatternPackage.DESIGN_PATTERN__COMPOSITIONS:
				return getCompositions();
			case PatternPackage.DESIGN_PATTERN__DIRECTEDASSOCIATIONS:
				return getDirectedassociations();
			case PatternPackage.DESIGN_PATTERN__REALIZATIONS:
				return getRealizations();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.DESIGN_PATTERN__ROLES:
				getRoles().clear();
				getRoles().addAll((Collection<? extends RoleElement>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__CLASSES:
				getClasses().clear();
				getClasses().addAll((Collection<? extends Pattern.Class>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__ROLEOFS:
				getRoleofs().clear();
				getRoleofs().addAll((Collection<? extends RoleOf>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__GENERALIZATIONS:
				getGeneralizations().clear();
				getGeneralizations().addAll((Collection<? extends Generalization>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__DEPENDENCES:
				getDependences().clear();
				getDependences().addAll((Collection<? extends Dependence>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__AGGREGATIONS:
				getAggregations().clear();
				getAggregations().addAll((Collection<? extends Aggregation>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__COMPOSITIONS:
				getCompositions().clear();
				getCompositions().addAll((Collection<? extends Composition>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__DIRECTEDASSOCIATIONS:
				getDirectedassociations().clear();
				getDirectedassociations().addAll((Collection<? extends DirectedAssociation>)newValue);
				return;
			case PatternPackage.DESIGN_PATTERN__REALIZATIONS:
				getRealizations().clear();
				getRealizations().addAll((Collection<? extends Realization>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.DESIGN_PATTERN__ROLES:
				getRoles().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__CLASSES:
				getClasses().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__ROLEOFS:
				getRoleofs().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__GENERALIZATIONS:
				getGeneralizations().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__DEPENDENCES:
				getDependences().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__AGGREGATIONS:
				getAggregations().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__COMPOSITIONS:
				getCompositions().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__DIRECTEDASSOCIATIONS:
				getDirectedassociations().clear();
				return;
			case PatternPackage.DESIGN_PATTERN__REALIZATIONS:
				getRealizations().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.DESIGN_PATTERN__ROLES:
				return roles != null && !roles.isEmpty();
			case PatternPackage.DESIGN_PATTERN__CLASSES:
				return classes != null && !classes.isEmpty();
			case PatternPackage.DESIGN_PATTERN__ROLEOFS:
				return roleofs != null && !roleofs.isEmpty();
			case PatternPackage.DESIGN_PATTERN__GENERALIZATIONS:
				return generalizations != null && !generalizations.isEmpty();
			case PatternPackage.DESIGN_PATTERN__DEPENDENCES:
				return dependences != null && !dependences.isEmpty();
			case PatternPackage.DESIGN_PATTERN__AGGREGATIONS:
				return aggregations != null && !aggregations.isEmpty();
			case PatternPackage.DESIGN_PATTERN__COMPOSITIONS:
				return compositions != null && !compositions.isEmpty();
			case PatternPackage.DESIGN_PATTERN__DIRECTEDASSOCIATIONS:
				return directedassociations != null && !directedassociations.isEmpty();
			case PatternPackage.DESIGN_PATTERN__REALIZATIONS:
				return realizations != null && !realizations.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DesignPatternImpl
