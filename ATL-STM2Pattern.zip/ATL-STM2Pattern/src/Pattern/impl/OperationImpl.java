/**
 */
package Pattern.impl;

import Pattern.AccessRightsType;
import Pattern.DataType;
import Pattern.MultiType;
import Pattern.Operation;
import Pattern.Parameter;
import Pattern.PatternPackage;
import Pattern.StaticType;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Operation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.OperationImpl#getReturnType <em>Return Type</em>}</li>
 *   <li>{@link Pattern.impl.OperationImpl#getAccessright <em>Accessright</em>}</li>
 *   <li>{@link Pattern.impl.OperationImpl#getStaticFlag <em>Static Flag</em>}</li>
 *   <li>{@link Pattern.impl.OperationImpl#getCiteName <em>Cite Name</em>}</li>
 *   <li>{@link Pattern.impl.OperationImpl#getMulti <em>Multi</em>}</li>
 *   <li>{@link Pattern.impl.OperationImpl#getParams <em>Params</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OperationImpl extends NameElementImpl implements Operation {
	/**
	 * The default value of the '{@link #getReturnType() <em>Return Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReturnType()
	 * @generated
	 * @ordered
	 */
	protected static final DataType RETURN_TYPE_EDEFAULT = DataType.INT;

	/**
	 * The cached value of the '{@link #getReturnType() <em>Return Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReturnType()
	 * @generated
	 * @ordered
	 */
	protected DataType returnType = RETURN_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAccessright() <em>Accessright</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessright()
	 * @generated
	 * @ordered
	 */
	protected static final AccessRightsType ACCESSRIGHT_EDEFAULT = AccessRightsType.PRIVATE;

	/**
	 * The cached value of the '{@link #getAccessright() <em>Accessright</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessright()
	 * @generated
	 * @ordered
	 */
	protected AccessRightsType accessright = ACCESSRIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #getStaticFlag() <em>Static Flag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticFlag()
	 * @generated
	 * @ordered
	 */
	protected static final StaticType STATIC_FLAG_EDEFAULT = StaticType.YES;

	/**
	 * The cached value of the '{@link #getStaticFlag() <em>Static Flag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticFlag()
	 * @generated
	 * @ordered
	 */
	protected StaticType staticFlag = STATIC_FLAG_EDEFAULT;

	/**
	 * The default value of the '{@link #getCiteName() <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCiteName()
	 * @generated
	 * @ordered
	 */
	protected static final String CITE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCiteName() <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCiteName()
	 * @generated
	 * @ordered
	 */
	protected String citeName = CITE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected static final MultiType MULTI_EDEFAULT = MultiType.YES;

	/**
	 * The cached value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected MultiType multi = MULTI_EDEFAULT;

	/**
	 * The cached value of the '{@link #getParams() <em>Params</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParams()
	 * @generated
	 * @ordered
	 */
	protected EList<Parameter> params;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OperationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.OPERATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DataType getReturnType() {
		return returnType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setReturnType(DataType newReturnType) {
		DataType oldReturnType = returnType;
		returnType = newReturnType == null ? RETURN_TYPE_EDEFAULT : newReturnType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.OPERATION__RETURN_TYPE, oldReturnType, returnType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AccessRightsType getAccessright() {
		return accessright;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAccessright(AccessRightsType newAccessright) {
		AccessRightsType oldAccessright = accessright;
		accessright = newAccessright == null ? ACCESSRIGHT_EDEFAULT : newAccessright;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.OPERATION__ACCESSRIGHT, oldAccessright, accessright));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StaticType getStaticFlag() {
		return staticFlag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStaticFlag(StaticType newStaticFlag) {
		StaticType oldStaticFlag = staticFlag;
		staticFlag = newStaticFlag == null ? STATIC_FLAG_EDEFAULT : newStaticFlag;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.OPERATION__STATIC_FLAG, oldStaticFlag, staticFlag));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCiteName() {
		return citeName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCiteName(String newCiteName) {
		String oldCiteName = citeName;
		citeName = newCiteName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.OPERATION__CITE_NAME, oldCiteName, citeName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MultiType getMulti() {
		return multi;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMulti(MultiType newMulti) {
		MultiType oldMulti = multi;
		multi = newMulti == null ? MULTI_EDEFAULT : newMulti;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.OPERATION__MULTI, oldMulti, multi));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Parameter> getParams() {
		if (params == null) {
			params = new EObjectContainmentEList<Parameter>(Parameter.class, this, PatternPackage.OPERATION__PARAMS);
		}
		return params;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PatternPackage.OPERATION__PARAMS:
				return ((InternalEList<?>)getParams()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.OPERATION__RETURN_TYPE:
				return getReturnType();
			case PatternPackage.OPERATION__ACCESSRIGHT:
				return getAccessright();
			case PatternPackage.OPERATION__STATIC_FLAG:
				return getStaticFlag();
			case PatternPackage.OPERATION__CITE_NAME:
				return getCiteName();
			case PatternPackage.OPERATION__MULTI:
				return getMulti();
			case PatternPackage.OPERATION__PARAMS:
				return getParams();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.OPERATION__RETURN_TYPE:
				setReturnType((DataType)newValue);
				return;
			case PatternPackage.OPERATION__ACCESSRIGHT:
				setAccessright((AccessRightsType)newValue);
				return;
			case PatternPackage.OPERATION__STATIC_FLAG:
				setStaticFlag((StaticType)newValue);
				return;
			case PatternPackage.OPERATION__CITE_NAME:
				setCiteName((String)newValue);
				return;
			case PatternPackage.OPERATION__MULTI:
				setMulti((MultiType)newValue);
				return;
			case PatternPackage.OPERATION__PARAMS:
				getParams().clear();
				getParams().addAll((Collection<? extends Parameter>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.OPERATION__RETURN_TYPE:
				setReturnType(RETURN_TYPE_EDEFAULT);
				return;
			case PatternPackage.OPERATION__ACCESSRIGHT:
				setAccessright(ACCESSRIGHT_EDEFAULT);
				return;
			case PatternPackage.OPERATION__STATIC_FLAG:
				setStaticFlag(STATIC_FLAG_EDEFAULT);
				return;
			case PatternPackage.OPERATION__CITE_NAME:
				setCiteName(CITE_NAME_EDEFAULT);
				return;
			case PatternPackage.OPERATION__MULTI:
				setMulti(MULTI_EDEFAULT);
				return;
			case PatternPackage.OPERATION__PARAMS:
				getParams().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.OPERATION__RETURN_TYPE:
				return returnType != RETURN_TYPE_EDEFAULT;
			case PatternPackage.OPERATION__ACCESSRIGHT:
				return accessright != ACCESSRIGHT_EDEFAULT;
			case PatternPackage.OPERATION__STATIC_FLAG:
				return staticFlag != STATIC_FLAG_EDEFAULT;
			case PatternPackage.OPERATION__CITE_NAME:
				return CITE_NAME_EDEFAULT == null ? citeName != null : !CITE_NAME_EDEFAULT.equals(citeName);
			case PatternPackage.OPERATION__MULTI:
				return multi != MULTI_EDEFAULT;
			case PatternPackage.OPERATION__PARAMS:
				return params != null && !params.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (returnType: ");
		result.append(returnType);
		result.append(", accessright: ");
		result.append(accessright);
		result.append(", staticFlag: ");
		result.append(staticFlag);
		result.append(", citeName: ");
		result.append(citeName);
		result.append(", multi: ");
		result.append(multi);
		result.append(')');
		return result.toString();
	}

} //OperationImpl
