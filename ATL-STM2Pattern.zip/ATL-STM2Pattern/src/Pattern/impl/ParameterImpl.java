/**
 */
package Pattern.impl;

import Pattern.DataType;
import Pattern.MultiType;
import Pattern.Parameter;
import Pattern.PatternPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Parameter</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.ParameterImpl#getParameterType <em>Parameter Type</em>}</li>
 *   <li>{@link Pattern.impl.ParameterImpl#getCiteName <em>Cite Name</em>}</li>
 *   <li>{@link Pattern.impl.ParameterImpl#getMulti <em>Multi</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ParameterImpl extends NameElementImpl implements Parameter {
	/**
	 * The default value of the '{@link #getParameterType() <em>Parameter Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameterType()
	 * @generated
	 * @ordered
	 */
	protected static final DataType PARAMETER_TYPE_EDEFAULT = DataType.INT;

	/**
	 * The cached value of the '{@link #getParameterType() <em>Parameter Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameterType()
	 * @generated
	 * @ordered
	 */
	protected DataType parameterType = PARAMETER_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCiteName() <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCiteName()
	 * @generated
	 * @ordered
	 */
	protected static final String CITE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCiteName() <em>Cite Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCiteName()
	 * @generated
	 * @ordered
	 */
	protected String citeName = CITE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected static final MultiType MULTI_EDEFAULT = MultiType.YES;

	/**
	 * The cached value of the '{@link #getMulti() <em>Multi</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMulti()
	 * @generated
	 * @ordered
	 */
	protected MultiType multi = MULTI_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ParameterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.PARAMETER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DataType getParameterType() {
		return parameterType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setParameterType(DataType newParameterType) {
		DataType oldParameterType = parameterType;
		parameterType = newParameterType == null ? PARAMETER_TYPE_EDEFAULT : newParameterType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.PARAMETER__PARAMETER_TYPE, oldParameterType, parameterType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCiteName() {
		return citeName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCiteName(String newCiteName) {
		String oldCiteName = citeName;
		citeName = newCiteName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.PARAMETER__CITE_NAME, oldCiteName, citeName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MultiType getMulti() {
		return multi;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMulti(MultiType newMulti) {
		MultiType oldMulti = multi;
		multi = newMulti == null ? MULTI_EDEFAULT : newMulti;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.PARAMETER__MULTI, oldMulti, multi));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.PARAMETER__PARAMETER_TYPE:
				return getParameterType();
			case PatternPackage.PARAMETER__CITE_NAME:
				return getCiteName();
			case PatternPackage.PARAMETER__MULTI:
				return getMulti();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.PARAMETER__PARAMETER_TYPE:
				setParameterType((DataType)newValue);
				return;
			case PatternPackage.PARAMETER__CITE_NAME:
				setCiteName((String)newValue);
				return;
			case PatternPackage.PARAMETER__MULTI:
				setMulti((MultiType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.PARAMETER__PARAMETER_TYPE:
				setParameterType(PARAMETER_TYPE_EDEFAULT);
				return;
			case PatternPackage.PARAMETER__CITE_NAME:
				setCiteName(CITE_NAME_EDEFAULT);
				return;
			case PatternPackage.PARAMETER__MULTI:
				setMulti(MULTI_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.PARAMETER__PARAMETER_TYPE:
				return parameterType != PARAMETER_TYPE_EDEFAULT;
			case PatternPackage.PARAMETER__CITE_NAME:
				return CITE_NAME_EDEFAULT == null ? citeName != null : !CITE_NAME_EDEFAULT.equals(citeName);
			case PatternPackage.PARAMETER__MULTI:
				return multi != MULTI_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (parameterType: ");
		result.append(parameterType);
		result.append(", citeName: ");
		result.append(citeName);
		result.append(", multi: ");
		result.append(multi);
		result.append(')');
		return result.toString();
	}

} //ParameterImpl
