/**
 */
package Pattern.impl;

import Pattern.Aggregation;
import Pattern.Composition;
import Pattern.Dependence;
import Pattern.DirectedAssociation;
import Pattern.PatternPackage;
import Pattern.Realization;
import Pattern.RoleElement;
import Pattern.RoleOf;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Element</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.RoleElementImpl#getRoleFrom <em>Role From</em>}</li>
 *   <li>{@link Pattern.impl.RoleElementImpl#getRealizationTo <em>Realization To</em>}</li>
 *   <li>{@link Pattern.impl.RoleElementImpl#getDependenceFrom <em>Dependence From</em>}</li>
 *   <li>{@link Pattern.impl.RoleElementImpl#getAggregationFrom <em>Aggregation From</em>}</li>
 *   <li>{@link Pattern.impl.RoleElementImpl#getCompositionFrom <em>Composition From</em>}</li>
 *   <li>{@link Pattern.impl.RoleElementImpl#getDirectedassociationFrom <em>Directedassociation From</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RoleElementImpl extends NameElementImpl implements RoleElement {
	/**
	 * The cached value of the '{@link #getRoleFrom() <em>Role From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoleFrom()
	 * @generated
	 * @ordered
	 */
	protected RoleOf roleFrom;

	/**
	 * The cached value of the '{@link #getRealizationTo() <em>Realization To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRealizationTo()
	 * @generated
	 * @ordered
	 */
	protected Realization realizationTo;

	/**
	 * The cached value of the '{@link #getDependenceFrom() <em>Dependence From</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDependenceFrom()
	 * @generated
	 * @ordered
	 */
	protected EList<Dependence> dependenceFrom;

	/**
	 * The cached value of the '{@link #getAggregationFrom() <em>Aggregation From</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregationFrom()
	 * @generated
	 * @ordered
	 */
	protected EList<Aggregation> aggregationFrom;

	/**
	 * The cached value of the '{@link #getCompositionFrom() <em>Composition From</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompositionFrom()
	 * @generated
	 * @ordered
	 */
	protected EList<Composition> compositionFrom;

	/**
	 * The cached value of the '{@link #getDirectedassociationFrom() <em>Directedassociation From</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDirectedassociationFrom()
	 * @generated
	 * @ordered
	 */
	protected EList<DirectedAssociation> directedassociationFrom;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleElementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.ROLE_ELEMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleOf getRoleFrom() {
		if (roleFrom != null && roleFrom.eIsProxy()) {
			InternalEObject oldRoleFrom = (InternalEObject)roleFrom;
			roleFrom = (RoleOf)eResolveProxy(oldRoleFrom);
			if (roleFrom != oldRoleFrom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PatternPackage.ROLE_ELEMENT__ROLE_FROM, oldRoleFrom, roleFrom));
			}
		}
		return roleFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleOf basicGetRoleFrom() {
		return roleFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRoleFrom(RoleOf newRoleFrom) {
		RoleOf oldRoleFrom = roleFrom;
		roleFrom = newRoleFrom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ROLE_ELEMENT__ROLE_FROM, oldRoleFrom, roleFrom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Realization getRealizationTo() {
		if (realizationTo != null && realizationTo.eIsProxy()) {
			InternalEObject oldRealizationTo = (InternalEObject)realizationTo;
			realizationTo = (Realization)eResolveProxy(oldRealizationTo);
			if (realizationTo != oldRealizationTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PatternPackage.ROLE_ELEMENT__REALIZATION_TO, oldRealizationTo, realizationTo));
			}
		}
		return realizationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Realization basicGetRealizationTo() {
		return realizationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRealizationTo(Realization newRealizationTo) {
		Realization oldRealizationTo = realizationTo;
		realizationTo = newRealizationTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ROLE_ELEMENT__REALIZATION_TO, oldRealizationTo, realizationTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Dependence> getDependenceFrom() {
		if (dependenceFrom == null) {
			dependenceFrom = new EObjectContainmentEList<Dependence>(Dependence.class, this, PatternPackage.ROLE_ELEMENT__DEPENDENCE_FROM);
		}
		return dependenceFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Aggregation> getAggregationFrom() {
		if (aggregationFrom == null) {
			aggregationFrom = new EObjectContainmentEList<Aggregation>(Aggregation.class, this, PatternPackage.ROLE_ELEMENT__AGGREGATION_FROM);
		}
		return aggregationFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Composition> getCompositionFrom() {
		if (compositionFrom == null) {
			compositionFrom = new EObjectContainmentEList<Composition>(Composition.class, this, PatternPackage.ROLE_ELEMENT__COMPOSITION_FROM);
		}
		return compositionFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DirectedAssociation> getDirectedassociationFrom() {
		if (directedassociationFrom == null) {
			directedassociationFrom = new EObjectContainmentEList<DirectedAssociation>(DirectedAssociation.class, this, PatternPackage.ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM);
		}
		return directedassociationFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PatternPackage.ROLE_ELEMENT__DEPENDENCE_FROM:
				return ((InternalEList<?>)getDependenceFrom()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE_ELEMENT__AGGREGATION_FROM:
				return ((InternalEList<?>)getAggregationFrom()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE_ELEMENT__COMPOSITION_FROM:
				return ((InternalEList<?>)getCompositionFrom()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM:
				return ((InternalEList<?>)getDirectedassociationFrom()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.ROLE_ELEMENT__ROLE_FROM:
				if (resolve) return getRoleFrom();
				return basicGetRoleFrom();
			case PatternPackage.ROLE_ELEMENT__REALIZATION_TO:
				if (resolve) return getRealizationTo();
				return basicGetRealizationTo();
			case PatternPackage.ROLE_ELEMENT__DEPENDENCE_FROM:
				return getDependenceFrom();
			case PatternPackage.ROLE_ELEMENT__AGGREGATION_FROM:
				return getAggregationFrom();
			case PatternPackage.ROLE_ELEMENT__COMPOSITION_FROM:
				return getCompositionFrom();
			case PatternPackage.ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM:
				return getDirectedassociationFrom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.ROLE_ELEMENT__ROLE_FROM:
				setRoleFrom((RoleOf)newValue);
				return;
			case PatternPackage.ROLE_ELEMENT__REALIZATION_TO:
				setRealizationTo((Realization)newValue);
				return;
			case PatternPackage.ROLE_ELEMENT__DEPENDENCE_FROM:
				getDependenceFrom().clear();
				getDependenceFrom().addAll((Collection<? extends Dependence>)newValue);
				return;
			case PatternPackage.ROLE_ELEMENT__AGGREGATION_FROM:
				getAggregationFrom().clear();
				getAggregationFrom().addAll((Collection<? extends Aggregation>)newValue);
				return;
			case PatternPackage.ROLE_ELEMENT__COMPOSITION_FROM:
				getCompositionFrom().clear();
				getCompositionFrom().addAll((Collection<? extends Composition>)newValue);
				return;
			case PatternPackage.ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM:
				getDirectedassociationFrom().clear();
				getDirectedassociationFrom().addAll((Collection<? extends DirectedAssociation>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.ROLE_ELEMENT__ROLE_FROM:
				setRoleFrom((RoleOf)null);
				return;
			case PatternPackage.ROLE_ELEMENT__REALIZATION_TO:
				setRealizationTo((Realization)null);
				return;
			case PatternPackage.ROLE_ELEMENT__DEPENDENCE_FROM:
				getDependenceFrom().clear();
				return;
			case PatternPackage.ROLE_ELEMENT__AGGREGATION_FROM:
				getAggregationFrom().clear();
				return;
			case PatternPackage.ROLE_ELEMENT__COMPOSITION_FROM:
				getCompositionFrom().clear();
				return;
			case PatternPackage.ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM:
				getDirectedassociationFrom().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.ROLE_ELEMENT__ROLE_FROM:
				return roleFrom != null;
			case PatternPackage.ROLE_ELEMENT__REALIZATION_TO:
				return realizationTo != null;
			case PatternPackage.ROLE_ELEMENT__DEPENDENCE_FROM:
				return dependenceFrom != null && !dependenceFrom.isEmpty();
			case PatternPackage.ROLE_ELEMENT__AGGREGATION_FROM:
				return aggregationFrom != null && !aggregationFrom.isEmpty();
			case PatternPackage.ROLE_ELEMENT__COMPOSITION_FROM:
				return compositionFrom != null && !compositionFrom.isEmpty();
			case PatternPackage.ROLE_ELEMENT__DIRECTEDASSOCIATION_FROM:
				return directedassociationFrom != null && !directedassociationFrom.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //RoleElementImpl
