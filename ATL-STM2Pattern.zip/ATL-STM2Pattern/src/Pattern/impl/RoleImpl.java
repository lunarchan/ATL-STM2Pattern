/**
 */
package Pattern.impl;

import Pattern.AbstractType;
import Pattern.Aggregation;
import Pattern.Attribute;
import Pattern.Composition;
import Pattern.Dependence;
import Pattern.DirectedAssociation;
import Pattern.Generalization;
import Pattern.Operation;
import Pattern.PatternPackage;
import Pattern.Role;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.RoleImpl#getAbstractflag <em>Abstractflag</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getGeneralizationTo <em>Generalization To</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getOperations <em>Operations</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getDependenceTo <em>Dependence To</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getAggregationTo <em>Aggregation To</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getCompositionTo <em>Composition To</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getDirectedassociationTo <em>Directedassociation To</em>}</li>
 *   <li>{@link Pattern.impl.RoleImpl#getGeneralizationFrom <em>Generalization From</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RoleImpl extends RoleElementImpl implements Role {
	/**
	 * The default value of the '{@link #getAbstractflag() <em>Abstractflag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstractflag()
	 * @generated
	 * @ordered
	 */
	protected static final AbstractType ABSTRACTFLAG_EDEFAULT = AbstractType.YES;

	/**
	 * The cached value of the '{@link #getAbstractflag() <em>Abstractflag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbstractflag()
	 * @generated
	 * @ordered
	 */
	protected AbstractType abstractflag = ABSTRACTFLAG_EDEFAULT;

	/**
	 * The cached value of the '{@link #getGeneralizationTo() <em>Generalization To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneralizationTo()
	 * @generated
	 * @ordered
	 */
	protected Generalization generalizationTo;

	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList<Attribute> attributes;

	/**
	 * The cached value of the '{@link #getOperations() <em>Operations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperations()
	 * @generated
	 * @ordered
	 */
	protected EList<Operation> operations;

	/**
	 * The cached value of the '{@link #getDependenceTo() <em>Dependence To</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDependenceTo()
	 * @generated
	 * @ordered
	 */
	protected EList<Dependence> dependenceTo;

	/**
	 * The cached value of the '{@link #getAggregationTo() <em>Aggregation To</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregationTo()
	 * @generated
	 * @ordered
	 */
	protected EList<Aggregation> aggregationTo;

	/**
	 * The cached value of the '{@link #getCompositionTo() <em>Composition To</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompositionTo()
	 * @generated
	 * @ordered
	 */
	protected EList<Composition> compositionTo;

	/**
	 * The cached value of the '{@link #getDirectedassociationTo() <em>Directedassociation To</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDirectedassociationTo()
	 * @generated
	 * @ordered
	 */
	protected EList<DirectedAssociation> directedassociationTo;

	/**
	 * The cached value of the '{@link #getGeneralizationFrom() <em>Generalization From</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneralizationFrom()
	 * @generated
	 * @ordered
	 */
	protected EList<Generalization> generalizationFrom;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.ROLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AbstractType getAbstractflag() {
		return abstractflag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAbstractflag(AbstractType newAbstractflag) {
		AbstractType oldAbstractflag = abstractflag;
		abstractflag = newAbstractflag == null ? ABSTRACTFLAG_EDEFAULT : newAbstractflag;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ROLE__ABSTRACTFLAG, oldAbstractflag, abstractflag));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Generalization getGeneralizationTo() {
		if (generalizationTo != null && generalizationTo.eIsProxy()) {
			InternalEObject oldGeneralizationTo = (InternalEObject)generalizationTo;
			generalizationTo = (Generalization)eResolveProxy(oldGeneralizationTo);
			if (generalizationTo != oldGeneralizationTo) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PatternPackage.ROLE__GENERALIZATION_TO, oldGeneralizationTo, generalizationTo));
			}
		}
		return generalizationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Generalization basicGetGeneralizationTo() {
		return generalizationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setGeneralizationTo(Generalization newGeneralizationTo) {
		Generalization oldGeneralizationTo = generalizationTo;
		generalizationTo = newGeneralizationTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PatternPackage.ROLE__GENERALIZATION_TO, oldGeneralizationTo, generalizationTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Attribute> getAttributes() {
		if (attributes == null) {
			attributes = new EObjectContainmentEList<Attribute>(Attribute.class, this, PatternPackage.ROLE__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Operation> getOperations() {
		if (operations == null) {
			operations = new EObjectContainmentEList<Operation>(Operation.class, this, PatternPackage.ROLE__OPERATIONS);
		}
		return operations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Dependence> getDependenceTo() {
		if (dependenceTo == null) {
			dependenceTo = new EObjectContainmentEList<Dependence>(Dependence.class, this, PatternPackage.ROLE__DEPENDENCE_TO);
		}
		return dependenceTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Aggregation> getAggregationTo() {
		if (aggregationTo == null) {
			aggregationTo = new EObjectContainmentEList<Aggregation>(Aggregation.class, this, PatternPackage.ROLE__AGGREGATION_TO);
		}
		return aggregationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Composition> getCompositionTo() {
		if (compositionTo == null) {
			compositionTo = new EObjectContainmentEList<Composition>(Composition.class, this, PatternPackage.ROLE__COMPOSITION_TO);
		}
		return compositionTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<DirectedAssociation> getDirectedassociationTo() {
		if (directedassociationTo == null) {
			directedassociationTo = new EObjectContainmentEList<DirectedAssociation>(DirectedAssociation.class, this, PatternPackage.ROLE__DIRECTEDASSOCIATION_TO);
		}
		return directedassociationTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Generalization> getGeneralizationFrom() {
		if (generalizationFrom == null) {
			generalizationFrom = new EObjectContainmentEList<Generalization>(Generalization.class, this, PatternPackage.ROLE__GENERALIZATION_FROM);
		}
		return generalizationFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PatternPackage.ROLE__ATTRIBUTES:
				return ((InternalEList<?>)getAttributes()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE__OPERATIONS:
				return ((InternalEList<?>)getOperations()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE__DEPENDENCE_TO:
				return ((InternalEList<?>)getDependenceTo()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE__AGGREGATION_TO:
				return ((InternalEList<?>)getAggregationTo()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE__COMPOSITION_TO:
				return ((InternalEList<?>)getCompositionTo()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE__DIRECTEDASSOCIATION_TO:
				return ((InternalEList<?>)getDirectedassociationTo()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE__GENERALIZATION_FROM:
				return ((InternalEList<?>)getGeneralizationFrom()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.ROLE__ABSTRACTFLAG:
				return getAbstractflag();
			case PatternPackage.ROLE__GENERALIZATION_TO:
				if (resolve) return getGeneralizationTo();
				return basicGetGeneralizationTo();
			case PatternPackage.ROLE__ATTRIBUTES:
				return getAttributes();
			case PatternPackage.ROLE__OPERATIONS:
				return getOperations();
			case PatternPackage.ROLE__DEPENDENCE_TO:
				return getDependenceTo();
			case PatternPackage.ROLE__AGGREGATION_TO:
				return getAggregationTo();
			case PatternPackage.ROLE__COMPOSITION_TO:
				return getCompositionTo();
			case PatternPackage.ROLE__DIRECTEDASSOCIATION_TO:
				return getDirectedassociationTo();
			case PatternPackage.ROLE__GENERALIZATION_FROM:
				return getGeneralizationFrom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.ROLE__ABSTRACTFLAG:
				setAbstractflag((AbstractType)newValue);
				return;
			case PatternPackage.ROLE__GENERALIZATION_TO:
				setGeneralizationTo((Generalization)newValue);
				return;
			case PatternPackage.ROLE__ATTRIBUTES:
				getAttributes().clear();
				getAttributes().addAll((Collection<? extends Attribute>)newValue);
				return;
			case PatternPackage.ROLE__OPERATIONS:
				getOperations().clear();
				getOperations().addAll((Collection<? extends Operation>)newValue);
				return;
			case PatternPackage.ROLE__DEPENDENCE_TO:
				getDependenceTo().clear();
				getDependenceTo().addAll((Collection<? extends Dependence>)newValue);
				return;
			case PatternPackage.ROLE__AGGREGATION_TO:
				getAggregationTo().clear();
				getAggregationTo().addAll((Collection<? extends Aggregation>)newValue);
				return;
			case PatternPackage.ROLE__COMPOSITION_TO:
				getCompositionTo().clear();
				getCompositionTo().addAll((Collection<? extends Composition>)newValue);
				return;
			case PatternPackage.ROLE__DIRECTEDASSOCIATION_TO:
				getDirectedassociationTo().clear();
				getDirectedassociationTo().addAll((Collection<? extends DirectedAssociation>)newValue);
				return;
			case PatternPackage.ROLE__GENERALIZATION_FROM:
				getGeneralizationFrom().clear();
				getGeneralizationFrom().addAll((Collection<? extends Generalization>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.ROLE__ABSTRACTFLAG:
				setAbstractflag(ABSTRACTFLAG_EDEFAULT);
				return;
			case PatternPackage.ROLE__GENERALIZATION_TO:
				setGeneralizationTo((Generalization)null);
				return;
			case PatternPackage.ROLE__ATTRIBUTES:
				getAttributes().clear();
				return;
			case PatternPackage.ROLE__OPERATIONS:
				getOperations().clear();
				return;
			case PatternPackage.ROLE__DEPENDENCE_TO:
				getDependenceTo().clear();
				return;
			case PatternPackage.ROLE__AGGREGATION_TO:
				getAggregationTo().clear();
				return;
			case PatternPackage.ROLE__COMPOSITION_TO:
				getCompositionTo().clear();
				return;
			case PatternPackage.ROLE__DIRECTEDASSOCIATION_TO:
				getDirectedassociationTo().clear();
				return;
			case PatternPackage.ROLE__GENERALIZATION_FROM:
				getGeneralizationFrom().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.ROLE__ABSTRACTFLAG:
				return abstractflag != ABSTRACTFLAG_EDEFAULT;
			case PatternPackage.ROLE__GENERALIZATION_TO:
				return generalizationTo != null;
			case PatternPackage.ROLE__ATTRIBUTES:
				return attributes != null && !attributes.isEmpty();
			case PatternPackage.ROLE__OPERATIONS:
				return operations != null && !operations.isEmpty();
			case PatternPackage.ROLE__DEPENDENCE_TO:
				return dependenceTo != null && !dependenceTo.isEmpty();
			case PatternPackage.ROLE__AGGREGATION_TO:
				return aggregationTo != null && !aggregationTo.isEmpty();
			case PatternPackage.ROLE__COMPOSITION_TO:
				return compositionTo != null && !compositionTo.isEmpty();
			case PatternPackage.ROLE__DIRECTEDASSOCIATION_TO:
				return directedassociationTo != null && !directedassociationTo.isEmpty();
			case PatternPackage.ROLE__GENERALIZATION_FROM:
				return generalizationFrom != null && !generalizationFrom.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (abstractflag: ");
		result.append(abstractflag);
		result.append(')');
		return result.toString();
	}

} //RoleImpl
