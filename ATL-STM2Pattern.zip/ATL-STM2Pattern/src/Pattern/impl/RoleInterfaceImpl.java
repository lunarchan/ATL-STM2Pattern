/**
 */
package Pattern.impl;

import Pattern.Operation;
import Pattern.PatternPackage;
import Pattern.Realization;
import Pattern.RoleInterface;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Interface</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Pattern.impl.RoleInterfaceImpl#getOperations <em>Operations</em>}</li>
 *   <li>{@link Pattern.impl.RoleInterfaceImpl#getRealizationFrom <em>Realization From</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RoleInterfaceImpl extends RoleElementImpl implements RoleInterface {
	/**
	 * The cached value of the '{@link #getOperations() <em>Operations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperations()
	 * @generated
	 * @ordered
	 */
	protected EList<Operation> operations;

	/**
	 * The cached value of the '{@link #getRealizationFrom() <em>Realization From</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRealizationFrom()
	 * @generated
	 * @ordered
	 */
	protected EList<Realization> realizationFrom;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleInterfaceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PatternPackage.Literals.ROLE_INTERFACE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Operation> getOperations() {
		if (operations == null) {
			operations = new EObjectContainmentEList<Operation>(Operation.class, this, PatternPackage.ROLE_INTERFACE__OPERATIONS);
		}
		return operations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Realization> getRealizationFrom() {
		if (realizationFrom == null) {
			realizationFrom = new EObjectContainmentEList<Realization>(Realization.class, this, PatternPackage.ROLE_INTERFACE__REALIZATION_FROM);
		}
		return realizationFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PatternPackage.ROLE_INTERFACE__OPERATIONS:
				return ((InternalEList<?>)getOperations()).basicRemove(otherEnd, msgs);
			case PatternPackage.ROLE_INTERFACE__REALIZATION_FROM:
				return ((InternalEList<?>)getRealizationFrom()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PatternPackage.ROLE_INTERFACE__OPERATIONS:
				return getOperations();
			case PatternPackage.ROLE_INTERFACE__REALIZATION_FROM:
				return getRealizationFrom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PatternPackage.ROLE_INTERFACE__OPERATIONS:
				getOperations().clear();
				getOperations().addAll((Collection<? extends Operation>)newValue);
				return;
			case PatternPackage.ROLE_INTERFACE__REALIZATION_FROM:
				getRealizationFrom().clear();
				getRealizationFrom().addAll((Collection<? extends Realization>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PatternPackage.ROLE_INTERFACE__OPERATIONS:
				getOperations().clear();
				return;
			case PatternPackage.ROLE_INTERFACE__REALIZATION_FROM:
				getRealizationFrom().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PatternPackage.ROLE_INTERFACE__OPERATIONS:
				return operations != null && !operations.isEmpty();
			case PatternPackage.ROLE_INTERFACE__REALIZATION_FROM:
				return realizationFrom != null && !realizationFrom.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //RoleInterfaceImpl
